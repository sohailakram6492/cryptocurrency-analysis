import pandas as pd
import pyodbc
import numpy as np
import datetime
import urllib
import sqlalchemy as sal
from sqlalchemy import create_engine
DB_connection = pyodbc.connect("Driver={SQL Server};"
                      "Server=tcp:atg-prod.database.windows.net;"
                      "Database=ATGPNRDB_TEST;"
                      "uid=atg-admin;pwd=prod24680*;")
cursor = DB_connection.cursor()


# engine = create_engine("mysql+pymysql://{user}:{pw}@localhost/{db}"
#                        .format(user="atg-admin",
#                                pw="prod24680*",
#                                db="ATGPNRDB_TEST"))

# server = 'tcp:atg-prod.database.windows.net' # to specify an alternate port
# database = 'ATGPNRDB_TEST' 
# username = 'atg-admin' 
# password = 'prod24680*'

# params = urllib.parse.quote_plus("'DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password")

# engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
# engine = sal.create_engine(‘mssql+pyodbc://server/database?driver=SQL Server?Trusted_Connection=yes’)
# engine = sal.create_engine(pyodbc+SQL Server://username:password@host:port/database’)


df = pd.read_csv('{}'.format('trips111.csv'))
df.fillna('', inplace=True)
# df.drop_duplicates(subset=['ACCT'], inplace=True)
# del df['RECKEY_NEW']
today = datetime.datetime.now()
print(today)
# df['EXPORTED_DATE'] = today
print(df.columns)
# print(df['EXPORTED_DATE'])
# df.to_csv('newacts.csv', index=False)
# exit()
header = df.columns.tolist()
headers = map((lambda x: x.strip()), header)
print(header)
print(headers)
# exit()
insert = 'INSERT INTO {} ('.format('TCTRIPS_BO') + ', '.join(headers) + ') VALUES '
df['uploaded']=['0']*df.shape[0]
print(df)
df.to_sql('TCTRIPS_BO', con = engine, if_exists = 'append', chunksize = 1000)
exit()

try:
# exit()
    rowCount = 1
    for i,row in df.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        inserting = inserting.replace("'nan'",'NULL')
        inserting = inserting.replace("'NaT'",'NULL')
        print(inserting)
        cursor.execute(inserting )
        
        print('Inerted Records ---> ' + str(rowCount))
        rowCount = rowCount +1
        # df.loc[i, 'uploaded'] = "1"
    # cnxnLive.commit()
except Exception as e:
    print(e)