import pyodbc
import pandas as pd
from datetime import *
import glob
import os
import datetime
import csv
# Database connection
DB_connection = pyodbc.connect("Driver={SQL Server};"
                      "Server=tcp:atg-prod.database.windows.net;"
                      "Database=ATGPNRDB_LIVE;"
                      "uid=atg-admin;pwd=prod24680*;")
cursor = DB_connection.cursor()

# TCtrips_DB = pd.read_sql_query("Select * from TCTRIPS", DB_connection)
# print(df)

current_directory = os.getcwd()
print(current_directory)

folder_path = [d for d in os.listdir(current_directory) if os.path.isdir(d) & (~d.startswith('.'))]

# if len(folder_path) == 1:
#     folder_path = folder_path[0]
# else:
#     print('There are two or more folder to read. Please Place 1 folder in this directory.')
#     exit()

file_names = ['TCCARS.csv','TCTRIPS.csv','TCHOTEL.csv', 'TCLEGS.csv', 'TCSERVICES.csv','TCUDIDS.csv','TCACCTS.csv']

# print(os.listdir(folder_path))
directories = []
for folder in folder_path:
    print(folder)
    
    for j in glob.glob("{}\*.csv".format(folder)):
        print(j)
        split = j.split('\\')
        print(split)
        tableName = split[-1].replace('.csv', '').replace('.CSV', '').replace('(','').replace(')','').strip()
        tableName = ''.join([i for i in tableName if not i.isdigit()])
        tableName = tableName.strip()
        # print(tableName)
        if tableName not in ['ACCOUNTREPORT','DELETED_RECORDS', 'DIRECTORIES', 'ERROR_REPORT']:
            print(tableName)
            df = pd.read_csv('{}'.format(j))
            if tableName == 'TCTRIPS':
                print('trips')
                print('trips file')
                # df = pd.read_csv('{}'.format(full_path))
                # print(df)
                df['INVDATE'] = pd.to_datetime(df['INVDATE'])
                first_date = df['INVDATE'].min().strftime("%Y-%m-%d")
                last_date = df['INVDATE'].max().strftime("%Y-%m-%d")
                # first_date = "2021-10-01"
                # last_date = "2021-10-30"
                print(first_date)
                print(last_date)
                # TCtrips_DB = pd.read_sql_query("Select * from TCTRIPS WHERE INVDATE BETWEEN '{}' and '{}' ".format(first_date,last_date), DB_connection)
                TCtripsMax_reckey = pd.read_sql_query("Select max(Reckey) AS RECKEY from TCTRIPS", DB_connection)
                # print(len(TCtrips_DB))
                Max_Reckey = int(TCtripsMax_reckey['RECKEY'])
                print("Maximum Reckey is --------",Max_Reckey)
                # print(TCtrips_DB['ACCT'],'---------------', df['ACCT'])
                # Data_found = df[df['ACCT'].isin(TCtrips_DB['ACCT']) ]
                # print(Data_found)
                df['RECKEY'] = df['RECKEY'].apply(lambda x: str(x).replace('.0','').replace('.',''))
                df['INVOICE'] = df['INVOICE'].apply(lambda x: str(x).replace('.0','').replace('.',''))
                # Creating Reckey 
                print('----Creating Reckey----')
                for i, row in df.iterrows():
                    Max_Reckey += 1
                    df.loc[i,'RECKEY_NEW'] = Max_Reckey
                cols = df.columns.tolist()
                cols = cols[-1:] + cols[:-1]
                df = df[cols]
                df.to_csv('new.csv', index=False)
                print(len(df))
            # print(df)
            # exit()






exit()


for file in os.listdir(folder_path):
    for i in range(len(folder_path)):
        if file in file_names:
            print(file.split('.')[0])
            file_name = file.split('.')[0]
            full_path = str(current_directory)+"\\" + str(folder_path) + "\\" + str(file)
            print('full path ------------',full_path)
            if file_name == 'TCTRIPS':
                print('trips file')
                df = pd.read_csv('{}'.format(full_path))
                print(df)
                df['INVDATE'] = pd.to_datetime(df['INVDATE'])
                first_date = df['INVDATE'].min().strftime("%Y-%m-%d")
                last_date = df['INVDATE'].max().strftime("%Y-%m-%d")
                # first_date = "2021-10-01"
                # last_date = "2021-10-30"
                print(first_date)
                print(last_date)
                # TCtrips_DB = pd.read_sql_query("Select * from TCTRIPS WHERE INVDATE BETWEEN '{}' and '{}' ".format(first_date,last_date), DB_connection)
                TCtripsMax_reckey = pd.read_sql_query("Select max(Reckey) AS RECKEY from TCTRIPS", DB_connection)
                # print(len(TCtrips_DB))
                Max_Reckey = int(TCtripsMax_reckey['RECKEY'])
                print("Maximum Reckey is --------",Max_Reckey)
                # print(TCtrips_DB['ACCT'],'---------------', df['ACCT'])
                # Data_found = df[df['ACCT'].isin(TCtrips_DB['ACCT']) ]
                # print(Data_found)
                df['RECKEY'] = df['RECKEY'].apply(lambda x: str(x).replace('.0','').replace('.',''))
                df['INVOICE'] = df['INVOICE'].apply(lambda x: str(x).replace('.0','').replace('.',''))
                # Creating Reckey 
                print('----Creating Reckey----')
                for i, row in df.iterrows():
                    Max_Reckey += 1
                    df.loc[i,'RECKEY_NEW'] = Max_Reckey
                cols = df.columns.tolist()
                cols = cols[-1:] + cols[:-1]
                df = df[cols]
                # df.to_csv('new.csv', index=False)
                print(len(df))
            if file_name == 'TCHOTEL':
                df_hotel = pd.read_csv('{}'.format(full_path))
                df_hotel.fillna('', inplace=True)
                print(len(df_hotel))
                if(len(df_hotel)):
                    print('in hotel file')
                    df_hotel = df_hotel.loc[df_hotel['RECKEY'] == (df['RECKEY']), 'RECKEY'] = df['RECKEY_NEW']
                    print(df_hotel)
                    # exit()
        # else:
        #     continue
        

    