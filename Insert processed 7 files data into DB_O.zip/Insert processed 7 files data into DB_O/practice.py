import pyodbc
import pandas as pd
import numpy as np
from datetime import *
import glob
import os
import datetime
import csv
from dateutil import parser
from shutil import rmtree
# Database connection
DB_connection = pyodbc.connect("Driver={SQL Server};"
                      "Server=tcp:atg-prod.database.windows.net;"
                      "Database=ATGPNRDB_TEST;"
                      "uid=atg-admin;pwd=prod24680*;")
cursor = DB_connection.cursor()

# TCtrips_DB = pd.read_sql_query("Select * from TCTRIPS", DB_connection)
# print(df)
# date_entry = input('Enter a date in YYYY-MM-DD format')
# year, month, day = map(int, date_entry.split('-'))
# date1 = datetime.date(year, month, day)
def InputDate():
    first_date = parser.parse(input("Enter First date (YYYY-MM-DD format): "))
    last_date = parser.parse(input("Enter Last date (YYYY-MM-DD format): "))
    first_date = first_date.strftime("%Y-%m-%d")
    last_date = last_date.strftime("%Y-%m-%d")
    print('First Date --- > ',first_date)
    print('Last Date --- > ',last_date)
    return first_date, last_date

# exit()
current_directory = os.getcwd()
print('Path is --> ',current_directory)

folder_path = [d for d in os.listdir(current_directory) if os.path.isdir(d) & (~d.startswith('.'))]
print(folder_path)

if len(folder_path) == 1:
    folder_path = folder_path[0]
else:
    print('There are two or more folder to read. Please Place 1 folder in this directory.')
    exit()

file_names = ['TCCARS.csv','TCTRIPS.csv','TCHOTEL.csv', 'TCLEGS.csv', 'TCSERVICES.csv','TCUDIDS.csv','TCACCTS.csv']

# print(os.listdir(folder_path))
path = os.listdir(folder_path)
print('folder is-----',path)

for i in path:
    full_path = str(current_directory)+ "\\" + str(folder_path) + "\\" + str(i)
    # print('path is -------',full_path)
    # print(i)
    file_name = i.split('.')[0]
    # print(file_name)
    if file_name == 'TCTRIPS':
        df_trips = pd.read_csv('{}'.format(full_path))
        df_trips.fillna('', inplace=True)
        # print(len(df_trips))
    if file_name == 'TCHOTEL':
        df_hotel = pd.read_csv('{}'.format(full_path))
        df_hotel.fillna('', inplace=True)
        # print(len(df_hotel))
    if file_name == 'TCLEGS':
        df_legs = pd.read_csv('{}'.format(full_path))
        df_legs.fillna('', inplace=True)
        # print(len(df_legs))
    if file_name == 'TCSERVICES':
        df_services = pd.read_csv('{}'.format(full_path))
        df_services.fillna('', inplace=True)
        # print(len(df_services))
    if file_name == 'TCACCTS':
        df_accts = pd.read_csv('{}'.format(full_path))
        df_accts.fillna('', inplace=True)
        # print(len(df_accts))
    if file_name == 'TCUDIDS':
        df_udids = pd.read_csv('{}'.format(full_path))
        df_udids.fillna('', inplace=True)
        # print(len(df_udids))
    if file_name == 'TCCARS':
        df_cars = pd.read_csv('{}'.format(full_path))
        df_cars.fillna('', inplace=True)
        # print(len(df_cars))
    
    
# exit()
trips_acct = tuple(df_trips['ACCT'])
trips_acct = [str(value) for value in trips_acct]
trips_acct = tuple(set(trips_acct))
# print("Accounts --> {} ".format(trips_acct))
# print("\nAre you sure you want to delete data from Dattabse? Accounts {} and Start_Date {} and End_Date {}".format(trips_acct,first_date, last_date))
# def takeInput():
#     Yes_Or_No = (input("\nIF Yes Press 1 IF No press 0: "))
#     # print(Yes_Or_No)
#     return Yes_Or_No
    
def Delete_From_DB(Yes_Or_No,first_date,last_date):
    # first_date,last_date = InputDate()
    trips_acct = tuple(df_trips['ACCT'])
    trips_acct = [str(value) for value in trips_acct]
    trips_acct = tuple(set(trips_acct))
    print('ok')
    # exit()
    tclegs_delete_query = ("DELETE from TCLEGS_BO where RECKEY in (SELECT RECKEY FROM TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {})".format(first_date,last_date,trips_acct))
    print(tclegs_delete_query)
    # cursor.execute(tclegs_delete_query)
    # cursor.commit()
    # exit()
    tchotel_delete_query = ("DELETE from TCHOTEL_BO where RECKEY in (SELECT RECKEY FROM TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {})".format(first_date,last_date,trips_acct))
    print(tchotel_delete_query)
    # cursor.execute(tchotel_delete_query)
    # cursor.commit()
    tcudids_delete_query = ("DELETE from TCUDIDS_BO where RECKEY in (SELECT RECKEY FROM TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {})".format(first_date,last_date,trips_acct))
    print(tcudids_delete_query)
    # cursor.execute(tcudids_delete_query)
    # cursor.commit()
    tcservices_delete_query = ("DELETE from TCSERVIC_BO where RECKEY in (SELECT RECKEY FROM TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {})".format(first_date,last_date,trips_acct))
    print(tcservices_delete_query)
    # cursor.execute(tcservices_delete_query)
    # cursor.commit()
    tccars_delete_query = ("DELETE from TCCARS_BO where RECKEY in (SELECT RECKEY FROM TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {})".format(first_date,last_date,trips_acct))
    print(tccars_delete_query)
    # cursor.execute(tccars_delete_query)
    # cursor.commit()
    tctrips_delete_query = ("DELETE from TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {} ".format(first_date,last_date,trips_acct))
    print(tctrips_delete_query)
    # cursor.execute(tctrips_delete_query)
    # cursor.commit()

def get_non_negative_int(prompt):
    date1,date2 = InputDate()
    while True:
        try:
            print("\nAre you sure you want to delete data from Dattabse? Accounts {} and Start_Date {} and End_Date {}".format(trips_acct,date1, date2))
            value = int(input(prompt))
        except ValueError:
            print("Sorry, I didn't understand that.")
            continue
        
        if value == 1:
            # print("Sorry, your response must not be negative.")
            Delete_From_DB(value,date1,date2)
            
        if value < 0:
            print("Sorry, your response must not be negative.")
            continue
        elif value > 1:
            print("Sorry, your response not matched, \nPlease IF Yes Press 1 IF No press 0: ")
            continue
        else:
            break
    return value



def Insertion_into_DB(df_trips,df_hotel,df_cars,df_services,df_udids,df_accts,df_legs):
    DB_connection = pyodbc.connect("Driver={SQL Server};"
                      "Server=tcp:atg-prod.database.windows.net;"
                      "Database=ATGPNRDB_TEST;"
                      "uid=atg-admin;pwd=prod24680*;")
    cursor = DB_connection.cursor()
    cursor.execute("Select max(Reckey) from TCTRIPS_BO")
    TCtripsMax_reckey = cursor.fetchall()
    # print(TCtripsMax_reckey)
    # print(TCtripsMax_reckey[0][0])
    Max_Reckey = TCtripsMax_reckey[0][0]
    # print(Max_Reckey)
    # exit()

    if Max_Reckey :
        Max_Reckey = int(Max_Reckey)
    else:
        Max_Reckey = 2000000
    print("Maximum Reckey is --------",Max_Reckey)
    
    # TCtrips_DB = pd.read_sql_query("Select * from TCTRIPS WHERE INVDATE BETWEEN '{}' and '{}'  and ACCT in {}  ".format(trips_acct), DB_connection)
    # TCtrips_DB.fillna('', inplace=True)
    # print(TCtrips_DB)
    # Data_found = df_trips[df_trips['ACCT'].isin(TCtrips_DB['ACCT']) & df_trips['INVDATE'].isin(TCtrips_DB['INVDATE']) ]
    # print(len(Data_found))
    # if len(Data_found) != 0:
    #     print('there is data to be deleted')
    # exit()
    df_trips['RECKEY'] = df_trips['RECKEY'].apply(lambda x: str(x).replace('.0','').replace('.',''))
    df_hotel['RECKEY'] = df_hotel['RECKEY'].apply(lambda x: str(x).replace('.0','').replace('.',''))
    df_cars['RECKEY'] = df_cars['RECKEY'].apply(lambda x: str(x).replace('.0','').replace('.',''))
    df_legs['RECKEY'] = df_legs['RECKEY'].apply(lambda x: str(x).replace('.0','').replace('.',''))
    df_udids['RECKEY'] = df_udids['RECKEY'].apply(lambda x: str(x).replace('.0','').replace('.',''))
    df_services['RECKEY'] = df_services['RECKEY'].apply(lambda x: str(x).replace('.0','').replace('.',''))
    
    df_trips['INVOICE'] = df_trips['INVOICE'].apply(lambda x: str(x).replace('.0','').replace('.',''))
    # df_trips['RECKEY_NEW'] = df_trips['RECKEY']
    # df_trips.drop('RECKEY_NEW', axis=1)
    # df_trips['RECKEY_NEW'] = df_trips['RECKEY_NEW'].apply(lambda Max_Reckey:int(Max_Reckey)+1)
    # df_trips['RECKEY_NEW'] = df_trips['RECKEY_NEW'].apply(lambda Max_Reckey:Max_Reckey+1)
    # Creating Reckey 
    print('----Creating Reckey----')
    df_trips.fillna(0, inplace=True)

    df_hotel['RECKEY_NEW']=['0']*df_hotel.shape[0]

    for i, row in df_trips.iterrows():
        Max_Reckey += 1
        df_trips.loc[i,'RECKEY_NEW'] = int(Max_Reckey)
        trips_reckey = row['RECKEY']
        # print(df_trips.loc[i,'RECKEY_NEW'])
        # exit()
    df_trips.to_csv('newtrips.csv', index=False)
    # trips_hotel = df_trips[df_trips['RECKEY'].isin(df_hotel['RECKEY'])]
    # print(trips_hotel['RECKEY_NEW'],trips_hotel['RECKEY'])
    # print(len(df_hotel))
    # print(len(trips_hotel))
    # exit()
    # df_hotel.loc[df_hotel['RECKEY'].isin(trips_hotel['RECKEY']), 'RECKEY'] = trips_hotel['RECKEY_NEW']
    print(df_trips['RECKEY'])
    # trips_hotel['RECKEY'] = pd.to_numeric(trips_hotel['RECKEY_NEW'])
    # print(type(df_trips['RECKEY']))
    print(df_hotel['RECKEY'])
    df_hotel.loc[df_hotel['RECKEY'].isin(df_trips['RECKEY']), 'RECKEY_NEW'] = df_trips['RECKEY_NEW']
    # df_hotel.to_csv('newhotel.csv', index=False)
    # exit()
    for h,row1 in df_hotel.iterrows():
        for i, row in df_trips.iterrows():
            if row['RECKEY'] == row1['RECKEY']:
                # print(row['RECKEY'])
                # print(row1['RECKEY'])
                df_hotel.loc[h,'RECKEY'] = df_trips.loc[i,'RECKEY_NEW']
    print("---------hotels reckey created--------")
    for c,row2 in df_cars.iterrows():
        for i, row in df_trips.iterrows():
            if row['RECKEY'] == row2['RECKEY']:
                # print(row['RECKEY'])
                # print(row2['RECKEY'])
                df_cars.loc[c,'RECKEY'] = df_trips.loc[i,'RECKEY_NEW']
            # exit()
    print("---------cars reckey created--------")
    for s,row3 in df_services.iterrows():
        for i, row in df_trips.iterrows():
            if row['RECKEY'] == row3['RECKEY']:
                # print(row['RECKEY'])
                # print(row1['RECKEY'])
                df_services.loc[s,'RECKEY'] = df_trips.loc[i,'RECKEY_NEW']
    print("---------service reckey created--------")
    for l,row4 in df_legs.iterrows():
        for i, row in df_trips.iterrows():
            if row['RECKEY'] == row4['RECKEY']:
                # print(row['RECKEY'])
                # print(row1['RECKEY'])
                df_legs.loc[l,'RECKEY'] = df_trips.loc[i,'RECKEY_NEW']
    print("---------legs reckey created--------")
    for u,row5 in df_udids.iterrows():
        for i, row in df_trips.iterrows():
            if row['RECKEY'] == row5['RECKEY']:
                # print(row['RECKEY'])
                # print(row1['RECKEY'])
                df_udids.loc[u,'RECKEY'] = df_trips.loc[i,'RECKEY_NEW']
    print("---------udids reckey created--------")
        # print("---------trips reckey created--------",i)
        
    # cols = df_trips.columns.tolist()
    # cols = cols[-1:] + cols[:-1]
    # df_trips = df_trips[cols]
    
    # df_hotel.loc[df_trips['RECKEY'].isin(df_hotel['RECKEY']), ['RECKEY']] = df_trips['RECKEY_NEW']
    
    df_trips['RECKEY'] = df_trips['RECKEY_NEW']
    # df_trips['EXPORTED'] = 3
    # today = datetime.datetime.now()
    
    # df_trips['EXPORTED_DATE'] = today
    del df_trips['RECKEY_NEW']
    df_trips.to_csv('trips111.csv', index=False)
    
    # trips_hotel = df_hotel[df_hotel['RECKEY'].isin(df_trips['RECKEY'])]
    # print(len(trips_hotel))
    # df_hotel['RECKEY_NEW'] = df_hotel.loc[trips_hotel['RECKEY'].isin(df_hotel['RECKEY']), 'RECKEY'] = trips_hotel['RECKEY_NEW']
    # df_hotel['RECKEY_NEW'] = np.where(trips_hotel['RECKEY'].isin(df_hotel['RECKEY']), trips_hotel['RECKEY_NEW'],False)
    # df_cars.loc[df_trips['RECKEY'].isin(df_cars['RECKEY']), 'RECKEY'] = df_trips['RECKEY_NEW']
    # df_hotel.loc[df_trips['RECKEY'].isin(df_hotel['RECKEY']), 'RECKEY'] = df_trips['RECKEY_NEW']
    df_trips.to_csv('newtrips.csv', index=False)
    
    # df_services.to_csv('newservice.csv', index=False)
    # df_legs.to_csv('newlegs.csv', index=False)
    # df_udids.to_csv('newudids.csv', index=False)
    # df_hotel.to_csv('newhotel.csv', index=False)
    # df_cars.to_csv('newcars.csv', index=False)
    # print(len(df_trips['RECKEY']))
    # trip_header = df_trips.columns.tolist()
    # trips_headers = map((lambda x: x.strip()), trip_header)
    # print(headers)
    # exit()
    DB_connection = pyodbc.connect("Driver={SQL Server};"
                                    "Server=tcp:atg-prod.database.windows.net;"
                                    "Database=ATGPNRDB_TEST;"
                                    "uid=atg-admin;pwd=prod24680*;")
    cursor = DB_connection.cursor()
    insert = 'INSERT INTO {} ('.format('TCTRIPS_BO') + ', '.join(df_trips.columns) + ') VALUES '
    df_trips['uploaded']=['0']*df_trips.shape[0]
    # try:
    rowCount = 1
    for i,row in df_trips.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        inserting = inserting.replace("'nan'",'NULL')
        inserting = inserting.replace("'NaT'",'NULL')
        print(inserting)
        cursor.execute(inserting )
        
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
        # df.loc[i, 'uploaded'] = "1"
    cursor.commit()
    
    insert = 'INSERT INTO {} ('.format('TCHOTEL_BO') + ', '.join(df_hotel.columns) + ') VALUES '
    df_hotel['uploaded']=['0']*df_hotel.shape[0]
    # try:
    rowCount = 1
    for i,row in df_hotel.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        inserting = inserting.replace("'nan'",'NULL')
        inserting = inserting.replace("'NaT'",'NULL')
        print(inserting)
        cursor.execute(inserting )
        
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
        # df.loc[i, 'uploaded'] = "1"
    cursor.commit()
    insert = 'INSERT INTO {} ('.format('TCLEGS_BO') + ', '.join(df_legs.columns) + ') VALUES '
    df_legs['uploaded']=['0']*df_legs.shape[0]
    # try:
    rowCount = 1
    for i,row in df_legs.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        inserting = inserting.replace("'nan'",'NULL')
        inserting = inserting.replace("'NaT'",'NULL')
        print(inserting)
        cursor.execute(inserting )
        
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
        # df.loc[i, 'uploaded'] = "1"
    cursor.commit()
    DB_connection = pyodbc.connect("Driver={SQL Server};"
                      "Server=tcp:atg-prod.database.windows.net;"
                      "Database=ATGPNRDB_TEST;"
                      "uid=atg-admin;pwd=prod24680*;")
    cursor = DB_connection.cursor()
    df_services.fillna('', inplace=True)
    insert = 'INSERT INTO {} ('.format('TCSERVIC_BO') + ', '.join(df_services.columns) + ') VALUES '
    df_services['uploaded']=['0']*df_services.shape[0]
    # try:
    rowCount = 1
    for i,row in df_services.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        inserting = inserting.replace("'nan'",'NULL')
        inserting = inserting.replace("'NaT'",'NULL')
        print(inserting)
        cursor.execute(inserting )
        
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
        # df.loc[i, 'uploaded'] = "1"
    cursor.commit()
    
    insert = 'INSERT INTO {} ('.format('TCCARS_BO') + ', '.join(df_cars.columns) + ') VALUES '
    df_cars['uploaded']=['0']*df_cars.shape[0]
    # try:
    rowCount = 1
    for i,row in df_cars.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        inserting = inserting.replace("'nan'",'NULL')
        inserting = inserting.replace("'NaT'",'NULL')
        print(inserting)
        cursor.execute(inserting )
        
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
        # df.loc[i, 'uploaded'] = "1"
    cursor.commit()
    df_accts.drop_duplicates(subset=['ACCT'], inplace=True)
    insert = 'INSERT INTO {} ('.format('TCACCTS_BO') + ', '.join(df_accts.columns) + ') VALUES '
    df_accts['uploaded']=['0']*df_accts.shape[0]
    # try:
    rowCount = 1
    for i,row in df_accts.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        inserting = inserting.replace("'nan'",'NULL')
        inserting = inserting.replace("'NaT'",'NULL')
        print(inserting)
        cursor.execute(inserting )
        
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
        # df.loc[i, 'uploaded'] = "1"
    cursor.commit()
    

try:
    # get_non_negative_int("\nIF Yes Press 1 IF No press 0: ")
    for i in path:
        full_path = str(current_directory)+ "\\" + str(folder_path) + "\\" + str(i)
        # print('path is -------',full_path)
        # print(i)
        file_name = i.split('.')[0]
        # print(file_name)
        if file_name == 'TCTRIPS':
            df_trips = pd.read_csv('{}'.format(full_path))
            df_trips.fillna('', inplace=True)
            # print(len(df_trips))
        if file_name == 'TCHOTEL':
            df_hotel = pd.read_csv('{}'.format(full_path))
            df_hotel.fillna('', inplace=True)
            # print(len(df_hotel))
        if file_name == 'TCLEGS':
            df_legs = pd.read_csv('{}'.format(full_path))
            df_legs.fillna('', inplace=True)
            # print(len(df_legs))
        if file_name == 'TCSERVICES':
            df_services = pd.read_csv('{}'.format(full_path))
            df_services.fillna('', inplace=True)
            # print(len(df_services))
        if file_name == 'TCACCTS':
            df_accts = pd.read_csv('{}'.format(full_path))
            df_accts.fillna('', inplace=True)
            # print(len(df_accts))
        if file_name == 'TCUDIDS':
            df_udids = pd.read_csv('{}'.format(full_path))
            df_udids.fillna('', inplace=True)
            # print(len(df_udids))
        if file_name == 'TCCARS':
            df_cars = pd.read_csv('{}'.format(full_path))
            df_cars.fillna('', inplace=True)
            # print(len(df_cars))
    print(len(df_trips.columns))
    print(df_trips.columns)
    Insertion_into_DB(df_trips,df_hotel,df_cars,df_services,df_udids,df_accts,df_legs)
    rmtree(folder_path)
except Exception as e:
    print(e)
# exit()



    # print(len(df_hotel['RECKEY']))
    # df_hotel.loc[df_hotel['RECKEY']== df_trips['RECKEY'], df_hotel.loc['RECKEY']] = df_trips['RECKEY_NEW']
    # print(df_hotel)
# exit()

# for file in os.listdir(folder_path):
#     if file in file_names:
#         print(file.split('.')[0])
#         file_name = file.split('.')[0]
#         full_path = str(current_directory)+"\\" + str(folder_path) + "\\" + str(file)
#         print('full path ------------',full_path)
#         if file_name == 'TCTRIPS':
#             print('trips file')
#             df = pd.read_csv('{}'.format(full_path))
#             print(df)
#             df['INVDATE'] = pd.to_datetime(df['INVDATE'])
#             first_date = df['INVDATE'].min().strftime("%Y-%m-%d")
#             last_date = df['INVDATE'].max().strftime("%Y-%m-%d")
#             # first_date = "2021-10-01"
#             # last_date = "2021-10-30"
#             print(first_date)
#             print(last_date)
#             # TCtrips_DB = pd.read_sql_query("Select * from TCTRIPS WHERE INVDATE BETWEEN '{}' and '{}' ".format(first_date,last_date), DB_connection)
#             TCtripsMax_reckey = pd.read_sql_query("Select max(Reckey) AS RECKEY from TCTRIPS", DB_connection)
#             # print(len(TCtrips_DB))
#             Max_Reckey = int(TCtripsMax_reckey['RECKEY'])
#             print("Maximum Reckey is --------",Max_Reckey)
#             # print(TCtrips_DB['ACCT'],'---------------', df['ACCT'])
#             # Data_found = df[df['ACCT'].isin(TCtrips_DB['ACCT']) ]
#             # print(Data_found)
#             df['RECKEY'] = df['RECKEY'].apply(lambda x: str(x).replace('.0','').replace('.',''))
#             df['INVOICE'] = df['INVOICE'].apply(lambda x: str(x).replace('.0','').replace('.',''))
#             # Creating Reckey 
#             print('----Creating Reckey----')
#             for i, row in df.iterrows():
#                 Max_Reckey += 1
#                 df.loc[i,'RECKEY_NEW'] = Max_Reckey
#             cols = df.columns.tolist()
#             cols = cols[-1:] + cols[:-1]
#             df = df[cols]
#             # df.to_csv('new.csv', index=False)
#             print(len(df))
#         if file_name == 'TCHOTEL':
#             df_hotel = pd.read_csv('{}'.format(full_path))
#             df_hotel.fillna('', inplace=True)
#             print(len(df_hotel))
#             if(len(df_hotel)):
#                 print('in hotel file')
#                 df_hotel = df_hotel.loc[df_hotel['RECKEY'] == (df['RECKEY']), 'RECKEY'] = df['RECKEY_NEW']
#                 print(df_hotel)
#                 # exit()
        # else:
        #     continue
        

    