import pyodbc
import pandas as pd
import csv
import numpy as np
import chardet
import sys
# reload(sys)
# sys.setdefaultencoding('utf-8')
# Shows all columns
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

# ########Connect to database start here########
cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=sql-looker-db.database.windows.net;"
                         "Database=Looker_live;" 
                         "uid=atg-admin;pwd=Travel@123;")
cursor = cnxnLive.cursor()

# read database
# DataFileName= '202011Main.xlsx'
# df = pd.read_excel(DataFileName)




def insert_records(table, mycsv,StartDate,EndDate):
    print("\n----------------Master Data Script Function--------------------\n")
    #INSERT SOURCE RECORDS TO DESTINATION
    try:
        df = pd.read_excel(mycsv)
        headers = map((lambda x: x.strip()), df.columns)

        # below code will help to not insert the same data twice
        Reckey = pd.read_sql_query("SELECT RECKEY,LEGCNTR FROM MasterTrip_test WHERE invdate between '"+StartDate+"' and '"+EndDate+"'", cnxnLive)
        Reckey['recleg'] = Reckey['RECKEY'].apply(str) +'_' + Reckey['LEGCNTR'].apply(str)
        # print(df.reckey)

        Not_same = df[~(df.reckey.isin(Reckey.RECKEY) )]
        Same = df[(df.reckey.isin(Reckey.RECKEY) )]
        df3 = Reckey[~(Reckey.RECKEY.isin(df.reckey) )]
        df4 = Reckey[(Reckey.RECKEY.isin(df.reckey) )]
        # print(Not_same)
        print('#####################33')
        # print(Same)
        # exit()

        df.columns= df.columns.str.upper()
        df['recleg'] = df['RECKEY'].apply(str) +'_' + df['LEGCNTR'].apply(str)
        df = df[~df.recleg.isin(Reckey['recleg'])]
        
        del df['recleg']
        print('Fetch Data')



        # clean data field
        df['INVDATE'] = pd.to_datetime(df['INVDATE'], errors='coerce')
        df['BOOKDATE'] = pd.to_datetime(df['BOOKDATE'], errors='coerce')
        df['DEPDATE'] = pd.to_datetime(df['DEPDATE'], errors='coerce')
        df['ARRDATE'] = pd.to_datetime(df['ARRDATE'], errors='coerce')
        df['DATEIN'] = pd.to_datetime(df['DATEIN'], errors='coerce')
        df['CHECKOUT'] = pd.to_datetime(df['CHECKOUT'], errors='coerce')
        df['RENTDATE'] = pd.to_datetime(df['RENTDATE'], errors='coerce')
        df['RETURNDATE'] = pd.to_datetime(df['RETURNDATE'], errors='coerce')
        df['RDEPDATE'] = pd.to_datetime(df['RDEPDATE'], errors='coerce')
        df['RARRDATE'] = pd.to_datetime(df['RARRDATE'], errors='coerce')
        df['STRANDATE'] = pd.to_datetime(df['STRANDATE'], errors='coerce')
        df = df.replace("'",' ',regex=True)
        header = df.columns.tolist()
        headers = map((lambda x: x.strip()), header)
        insert = 'INSERT INTO {} ('.format(table) + ', '.join(headers) + ') VALUES '
        Not_same['uploaded']=['0']*Not_same.shape[0]
        # try:
        rowCount = 1

        # for inserting
        count = 1
        for i,row in Not_same.iterrows():
            values = map((lambda x: "'"+str(x)+"'"), row[:-1])
            inserting = insert +'('+ ', '.join(values) +');'
            inserting= inserting.replace("'nan'",'NULL')
            inserting= inserting.replace("'NaT'",'NULL')
            print(inserting)
            cnxnLive.execute(inserting )
            cnxnLive.commit()
            print('inserting Records' + str(count))
            count = count +1
            df.loc[i, 'uploaded'] = "1"
            # exit()

        reckey_same = Same.reckey
        # print(reckey_same)
        header = df.columns.tolist()
        headers = map((lambda x: x.strip()), header)
        update = 'UPDATE {} '.format(table) + 'SET ' +'=? '.join(headers) 
        # print(update)
        # exit()
        # df['uploaded']=['0']*df.shape[0]
        # df = df.drop(['RECKEY',], axis=1)

        # for i,row in Same.iterrows():
        #     header = df.columns.tolist()
        #     headers = map((lambda x: x.strip()), header) 
        #     #  + 'WHERE reckey=' .join(reckey_same)
        #     values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        #     update = 'UPDATE {} '.format(table) + 'SET ' + '=?,' .join(headers)+ 'WHERE reckey='"+reckey_same +"'  '
        #     print(update)
        #     exit()
        #     updating = update +'('+ ', '.join(values)+')'+ 'WHERE reckey= {}'
        #     updating= updating.replace("'nan'",'NULL')
        #     updating= updating.replace("'NaT'",'NULL')
        #     print(updating)
        #     # cnxnLive.execute(updating )
        #     # cnxnLive.commit()
        #     print('inserting Records' + str(count))
        #     count = count +1
        #     df.loc[i, 'uploaded'] = "1"

        # Same.replace(['NaT', 'nan', '', 'NaN'], 'Null', inplace=True)
        # Same.astype(object).where(Same.invoice , 'NULL')
        # Same['invdate'] = pd.to_datetime(Same['invdate'], errors='coerce')
        # Same['bookdate'] = pd.to_datetime(Same['bookdate'], errors='coerce')
        # Same['depdate'] = pd.to_datetime(Same['depdate'], errors='coerce')
        # Same['arrdate'] = pd.to_datetime(Same['arrdate'], errors='coerce')
        # Same['datein'] = pd.to_datetime(Same['datein'], errors='coerce')
        # Same['checkout'] = pd.to_datetime(Same['checkout'], errors='coerce')
        # Same['rentdate'] = pd.to_datetime(Same['rentdate'], errors='coerce')
        # Same['returndate'] = pd.to_datetime(Same['returndate'], errors='coerce')
        # Same['rdepdate'] = pd.to_datetime(Same['rdepdate'], errors='coerce')
        # Same['rarrdate'] = pd.to_datetime(Same['rarrdate'], errors='coerce')
        # Same['strandate'] = pd.to_datetime(Same['strandate'], errors='coerce')
        # Same = Same.replace("'",' ',regex=True)
        # Same['uploaded']=['0']*Same.shape[0]
        Same.fillna('None',inplace=True)
        # print(Same)
        # for updating
        for i,row in Same.iterrows():
            account = row['account']
            plusmin = row['plusmin']
            legcntr = row['legcntr']
            invoice = row['invoice']
            acct = row['acct']
            branch = row['branch']
            pseudocity = (row['pseudocity'])
            bookdate = row['bookdate']
            print(bookdate)
            valcarr = row['valcarr']
            ticket = row['ticket']
            passlast = row['passlast']
            passfrst = row['passfrst']
            mktfare = row['mktfare']
            offrdchg = row['offrdchg']
            reascode = row['reascode']
            airchg = row['airchg']
            basefare = row['basefare']
            svcfee = row['svcfee']
            trips_cred = row['trips_cred']
            cardnum = row['cardnum']
            recloc = row['recloc']
            domintl = row['domintl']
            trantype = row['trantype']
            break_1 = row['break_1']
            break_2 = row['break_2']
            break_3 = row['break_3']
            depdate = row['depdate']
            arrdate = row['arrdate']
            refundable = row['refundable']
            savingcode = row['savingcode']
            tourcode = row['tourcode']
            tickettype = row['tickettype']
            moneytype = row['moneytype']
            exchange = row['exchange']
            origticket = row['origticket']
            tax1 = row['tax1']
            tax2 = row['tax2']
            tax3 = row['tax3']
            tax4 = row['tax4']
            iatanbr = row['iatanbr']
            tkagent = row['tkagent']
            bkagent = row['bkagent']
            valcarmode = row['valcarmode']
            gds = row['gds']
            employeeid = row['employeeid']
            booking_nu = row['booking_nu']
            rplusmin = row['rplusmin']
            chaincod = row['chaincod']
            hotelchain = row['hotelchain']
            hotcity = row['hotcity']
            hotstate = row['hotstate']
            metro = row['metro']
            datein = row['datein']
            checkout = row['checkout']
            nights = row['nights']
            rooms = row['rooms']
            number_of_ = row['number_of_']
            roomtype = row['roomtype']
            bookrate = row['bookrate']
            hmoneytype = row['hmoneytype']
            hotel_plus = row['hotel_plus']
            hotphone = row['hotphone']
            reascodh = row['reascodh']
            hexcpcost = row['hexcpcost']
            hinvbyagcy = row['hinvbyagcy']
            confirmno = row['confirmno']
            hotsvgcode = row['hotsvgcode']
            hotelzip = row['hotelzip']
            hotctrycod = row['hotctrycod']
            hoteladdr1 = row['hoteladdr1']
            source = row['source']
            hotelzip = row['hotelzip']
            hotpropid = row['hotpropid']
            hoteladdr2 = row['hoteladdr2']
            company = row['company']
            autocity = row['autocity']
            autostat = row['autostat']
            citycode = row['citycode']
            rentdate = row['rentdate']
            returndate = row['returndate']
            days = row['days']
            abookrat = row['abookrat']
            cartype = row['cartype']
            ratetype = row['ratetype']
            amoneytype = row['amoneytype']
            car_plusmi = row['car_plusmi']
            car_code = row['car_code']
            reascoda = row['reascoda']
            aexcprat = row['aexcprat']
            cinvbyagcy = row['cinvbyagcy']
            aconfirmno = row['aconfirmno']
            carsvgcode = row['carsvgcode']
            carstdrate = row['carstdrate']
            cartrantyp = row['cartrantyp']
            airline = row['airline']
            origin = row['origin']
            destinat = row['destinat']
            rdepdate = row['rdepdate']
            rdepdttim = row['rdepdttim']
            rarrdate = row['rarrdate']
            rarrdttim = row['rarrdttim']
            clas = row['class']
            farebase = row['farebase']
            fltno = (row['fltno'])
            seqno = row['seqno']
            segment_no = row['segment_no']
            connect = row['connect']
            actfare = row['actfare']
            segamt = row['segamt']
            miles = row['miles']
            mode = row['mode']
            r_plusmin = row['r_plusmin']
            ditcode = row['ditcode']
            tktdesig = row['tktdesig']
            orgctrycod = row['orgctrycod']
            dstctrycod = row['dstctrycod']
            flduration = (row['flduration'])
            svccode = row['svccode']
            sdescript = row['sdescript']
            ssvcfee = row['ssvcfee']
            smoneytyp = row['smoneytyp']
            strandate = row['strandate']
            vendorcode = row['vendorcode']
            stax1 = row['stax1']
            stax2 = row['stax2']
            stax3 = row['stax3']
            stax4 = row['stax4']
            sftrantype = row['sftrantype']
            sf_credit_ = row['sf_credit_']
            scardnum = row['scardnum']
            smco = row['smco']
            classctnam = row['classctnam']
            hotreasn = row['hotreasn']
            rmtypedesc = row['rmtypedesc']
            reckey = (row['reckey'])
            plusmin = row['plusmin']
            legplusmin = row['legplusmin']
            legcntr = (row['legcntr'])
            rmtypedesc = row['rmtypedesc']
            # print(reckey)
            # print(legplusmin)
            


            print("""
            UPDATE MasterTrip_test
            SET  account=? , legcntr=? , invoice=? , acct=? , branch=? , pseudocity=? , valcarr=?, ticket=?, passlast=?, passfrst=?, mktfare=?, offrdchg=? , reascode=?, airchg=?, basefare=?, svcfee=?, trips_cred=?, cardnum=?, recloc=?, domintl=?, trantype=?, break_1=?, break_2=?,break_3=? , refundable=?, savingcode=?,tourcode=?, tickettype=?, moneytype=?, exchange=?, origticket=?, tax1=?,tax2=?,tax3=?,tax4=?,iatanbr=?,tkagent=?,bkagent=?,valcarmode=?,gds=?, employeeid=?, booking_nu=?, rplusmin=?, chaincod=?,hotcity=?,hotstate=?,metro=?,checkout=?,nights=?,rooms=?,number_of_=?,roomtype=?,bookrate=?,hmoneytype=?,hotel_plus=?,hotphone=?,reascodh=?,  hexcpcost=?,hinvbyagcy=?,confirmno=?, hotsvgcode=?, hotelzip=? ,hotctrycod=?,hoteladdr1=?,hoteladdr2=? , hotelchain=?,source=?,hotpropid=?,ratetype=?, connect=?, actfare=?, segamt=?,  company=?,autocity=?, autostat=?,citycode=?, days=?, abookrat=?, cartype=?, amoneytype=?, car_plusmi=?, car_code=?, reascoda=?, aexcprat=?, cinvbyagcy=?, aconfirmno=?, carsvgcode=?, carstdrate=?, cartrantyp=?, airline=?, origin=?, destinat=?, rdepdttim=?, rarrdttim=?, class=?, farebase=?, fltno=?, seqno=?, segment_no=?, miles=?, mode=?, r_plusmin=?, ditcode=?, tktdesig=?, orgctrycod=?, dstctrycod=?, flduration=?, svccode=?, sdescript=?, ssvcfee=?, smoneytyp=?,  vendorcode=?, stax1=?,stax2=?, stax3=?, stax4=?, sftrantype=? ,sf_credit_=?, scardnum=?, smco=?,classctnam=?, hotreasn=?, rmtypedesc=?, plusmin=?, legplusmin=?                              
            WHERE reckey=?
            """, (account, legcntr, invoice, acct,branch,pseudocity, valcarr, ticket, passlast,passfrst, mktfare, offrdchg, reascode, airchg , basefare , svcfee, trips_cred, cardnum, recloc,domintl,trantype,break_1,break_2,break_3,  refundable,savingcode,tourcode,tickettype ,moneytype,exchange, origticket, tax1, tax2, tax3, tax4, iatanbr, tkagent , bkagent , valcarmode, gds, employeeid, booking_nu, rplusmin, chaincod , hotcity, hotstate, metro, checkout, nights, rooms, number_of_, roomtype, bookrate,hmoneytype, hotel_plus, hotphone, reascodh, hexcpcost, hinvbyagcy, confirmno, hotsvgcode,hotelzip,hotctrycod, hoteladdr1,hoteladdr2, hotelchain,  source, hotpropid,  ratetype,connect,   actfare,   segamt, company,autocity, autostat,citycode, days, abookrat, cartype, amoneytype, car_plusmi, car_code, reascoda, aexcprat, cinvbyagcy, aconfirmno, carsvgcode, carstdrate, cartrantyp, airline, origin, destinat, rdepdttim, rarrdttim, clas, farebase, fltno, seqno, segment_no, miles, mode, r_plusmin, ditcode, tktdesig, orgctrycod, dstctrycod, flduration, svccode, sdescript, ssvcfee, smoneytyp, vendorcode, stax1,stax2, stax3, stax4, sftrantype ,sf_credit_, scardnum, smco,classctnam, hotreasn, rmtypedesc, plusmin, legplusmin, reckey  ))
            
            
            cursor.execute("""
            UPDATE MasterTrip_test
            SET  account=?  , legcntr=? , invoice=? , acct=? , branch=? , pseudocity=?, valcarr=?, ticket=?, passlast=?, passfrst=?, mktfare=?, offrdchg=? , reascode=?, airchg=?, basefare=?, svcfee=?, trips_cred=?, cardnum=?, recloc=?, domintl=?, trantype=?, break_1=?, break_2=?,break_3=?,  refundable=?, savingcode=?,tourcode=?, tickettype=?, moneytype=?, exchange=?, origticket=?, tax1=?,tax2=?,tax3=?,tax4=?,iatanbr=?,tkagent=?,bkagent=?,valcarmode=?,gds=?, employeeid=?, booking_nu=?, rplusmin=?, chaincod=?,hotcity=?,hotstate=?,metro=?,checkout=?,nights=?,rooms=?,number_of_=?,roomtype=?,bookrate=?,hmoneytype=?,hotel_plus=?,hotphone=?,reascodh=?,  hexcpcost=?,hinvbyagcy=?,confirmno=?, hotsvgcode=?, hotelzip=? ,hotctrycod=?,hoteladdr1=?,hoteladdr2=? , hotelchain=?,source=?,hotpropid=?,ratetype=?, connect=?, actfare=?, segamt=?,  company=?,autocity=?, autostat=?,citycode=?, days=?, abookrat=?, cartype=?, amoneytype=?, car_plusmi=?, car_code=?, reascoda=?, aexcprat=?, cinvbyagcy=?, aconfirmno=?, carsvgcode=?, carstdrate=?, cartrantyp=?, airline=?, origin=?, destinat=?, rdepdttim=?,  rarrdttim=?, class=?, farebase=?, fltno=?, seqno=?, segment_no=?, miles=?, mode=?, r_plusmin=?, ditcode=?, tktdesig=?, orgctrycod=?, dstctrycod=?, flduration=?, svccode=?, sdescript=?, ssvcfee=?, smoneytyp=?,  vendorcode=?, stax1=?,stax2=?, stax3=?, stax4=?, sftrantype=? ,sf_credit_=?, scardnum=?, smco=?,classctnam=?, hotreasn=?, rmtypedesc=?, plusmin=?, legplusmin=?                              
            WHERE reckey=?
            """, (account, legcntr, invoice, acct,branch,pseudocity, valcarr, ticket, passlast,passfrst, mktfare, offrdchg, reascode, airchg , basefare , svcfee, trips_cred, cardnum, recloc,domintl,trantype,break_1,break_2,break_3 , refundable,savingcode,tourcode,tickettype ,moneytype,exchange, origticket, tax1, tax2, tax3, tax4, iatanbr, tkagent , bkagent , valcarmode, gds, employeeid, booking_nu, rplusmin, chaincod , hotcity, hotstate, metro, checkout, nights, rooms, number_of_, roomtype, bookrate,hmoneytype, hotel_plus, hotphone, reascodh, hexcpcost, hinvbyagcy, confirmno, hotsvgcode,hotelzip,hotctrycod, hoteladdr1,hoteladdr2, hotelchain,  source, hotpropid,  ratetype,connect,   actfare,   segamt, company,autocity, autostat,citycode, days, abookrat, cartype, amoneytype, car_plusmi, car_code, reascoda, aexcprat, cinvbyagcy, aconfirmno, carsvgcode, carstdrate, cartrantyp, airline, origin, destinat, rdepdttim, rarrdttim, clas, farebase, fltno, seqno, segment_no, miles, mode, r_plusmin, ditcode, tktdesig, orgctrycod, dstctrycod, flduration, svccode, sdescript, ssvcfee, smoneytyp, vendorcode, stax1,stax2, stax3, stax4, sftrantype ,sf_credit_, scardnum, smco,classctnam, hotreasn, rmtypedesc, plusmin, legplusmin, reckey  ))
            cursor.commit()
            exit()


            #print(mycsv+'uploading row number: ',i)
            # b_cnxn.commit() #must commit unless your sql database auto-commits
        # except:
        #     df.to_excel('Expect.csv')
        # exit()
        
        
        df.to_csv('Expect_'+mycsv,index=False)
        return 'TranferDataSuccessfully'
    except:
        e = sys.exc_info()
        return e



if __name__ == "__main__":
	# insert_records()
	Response = insert_records('MasterTrip_test', '202103Main.xlsx', '2021-03-01', '2021-03-31')
	print(Response)
