import sys
import imaplib
import getpass
import email
import email.header
import base64
import re
import wget
import datetime
import os
import time
import requests
import uuid
import pyodbc
import subprocess
import pandas as pd
import numpy as np
import schedule
import shutil
from urllib.parse import unquote
from datetime import date, timedelta
from sendEmail3 import sendEmail
import sendEmail3
from LogFile import Task_Log
import LogFile
import ssl
ssl._create_default_https_context = ssl._create_unverified_context
from os import path
currDirPath = os.path.dirname(os.path.abspath(__file__))
os.chdir(currDirPath) 
print('Path',currDirPath)
if sys.argv[1]:
    ProcessPerameter = sys.argv[1]
else: 
    ProcessPerameter = 'Monthly'
today = datetime.date.today()
first = today.replace(day=1)
lastMonth = first - datetime.timedelta(days=1)
date_time_str = str(today)
date_time_obj = datetime.datetime.strptime(date_time_str, '%Y-%m-%d')
# print(date_time_obj.strftime("%m/%d/%Y"))
last_monday = date_time_obj - datetime.timedelta(days=date_time_obj.weekday()+7)
last_sunday = date_time_obj - datetime.timedelta(days=date_time_obj.weekday()+1)
# print("Today:", date_time_obj.strftime("%m/%d/%Y"))
# print("Last Monday:", last_monday.strftime("%m/%d/%Y"))
# print("Last Sunday:", last_sunday.strftime("%m/%d/%Y"))
# print("Last Week Number:",  last_sunday.strftime("%Y%m%U"))
# print("Last Week Number:",  last_monday.strftime("%m%d%Y"))
WeeklyFileName = last_monday.strftime("%Y%m%d") + '-'+last_sunday.strftime("%Y%m%d")
# import emailClass as email
# ProcessPerameter = 'Weekly'
EmailFrom = "noreply@atgtravel.com"  # Enter your address
EmailTo = "yshaukat.up@gmail.com"  # Enter receiver address
if ProcessPerameter == 'Weekly':
    allowed_subjects = ['Master Data Weekly','UDID Data Weekly']
    MainFileName = WeeklyFileName + 'Main.xlsx'
    UDIDFileName = WeeklyFileName + 'UDID.xlsx'
    TaskDescID = 11
    TaskRunDate = str(date_time_obj) + ' 04:00:00'
    EmailSubject = 'Master and UDID Data Weekly Process'
else:
    allowed_subjects = ['Master Data Monthly Refresh','UDID Data Monthly Refresh']
    MainFileName = lastMonth.strftime("%Y%m")+'Main.xlsx'
    UDIDFileName = lastMonth.strftime("%Y%m")+'UDID.xlsx'
    TaskDescID = 12
    TaskRunDate = str(date_time_obj) + ' 12:00:00'
    EmailSubject = 'Master and UDID Data Monthly Process'
def email_parser():
    
    print("-------Running Email Parser------")
    EMAIL_ACCOUNT = 'Parser@atgtravel.com'
    # while True:
    EMAIL_FOLDER = "INBOX"
    M = imaplib.IMAP4_SSL('smtp-mail.outlook.com')
    try:
        rv, data = M.login(
            EMAIL_ACCOUNT, 'Zag32043')
    except Exception as e:
        sendEmail3.sendEmail('UDID and Master Monthly Scheduled Task','Theres was an error in UDID and Master Monthly Scheduled Task.','')
        print("LOGIN FAILED!!! ")
        sys.exit(1)


    rv, mailboxes = M.list()
    rv, data = M.select(EMAIL_FOLDER)
    if rv == 'OK':
        print("Processing mailbox...\n")
        rv, data = M.search(None, "UNSEEN")
        
        for num in data[0].split():
            rv, data = M.fetch(num, '(RFC822)')
            msg = email.message_from_bytes(data[0][1])
            raw_email = data[0][1]
            raw_email_string = raw_email.decode('utf-8')
            email_message = email.message_from_string(raw_email_string)
            hdr = email.header.make_header(
                email.header.decode_header(msg['Subject']))
            from_email = email.header.make_header(
                email.header.decode_header(msg['from']))
            subject = str(hdr)
            links = []
            print(subject)
            print("-==-===-=-=-=-=-===-=-=-=-=-=-")
            print(allowed_subjects)

            if subject in allowed_subjects:
                links = []
                for part in email_message.walk():
                    
                    link_regex = re.compile("((https?):((//)|(\\\\))+([\w\d:#@%/;$()~_?\+-=\\\.&](#!)?)*)\n", re.DOTALL)
                    link = re.findall(link_regex, str(part))
                    test = re.sub(r'(?<!\.)=\n', '', str(part))
    
                    regex = r"(?i)\b((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'\".,<>?«»“”‘’]))"
                    urls = re.findall(regex,str(test))
                    urls = list(dict.fromkeys(urls))
                    urls = [x[0] for x in urls if 'nam11' in x[0]]

                    urls = urls[0].replace("=3D","=")                    
                    if subject=='Master Data Monthly Refresh' :
                        unique_filename = lastMonth.strftime("%Y%m")+'Main'
                    elif subject == "UDID Data Monthly Refresh":
                        unique_filename = lastMonth.strftime("%Y%m")+'UDID'
                    elif subject == "Master Data Weekly":
                        unique_filename = WeeklyFileName+'Main'
                    elif subject == "UDID Data Weekly":
                        unique_filename = WeeklyFileName+'UDID'
                    filenames = []
                    filenames.append(unique_filename)
                    print('unique file name:',unique_filename)
                    UniqueFileName = unique_filename+'.xlsx'
                    if str(path.isfile(UniqueFileName)) == 'False':
                        try:
                            wget.download(urls, f'''{currDirPath}\{unique_filename}.xlsx''')
                            print('------')
                            print(filenames[0])
                            time.sleep(10)
                            pd.set_option('display.max_columns', None)  # or 1000
                            pd.set_option('display.max_rows', None)  # or 1000
                            pd.set_option('display.max_colwidth', None)  # or 199
                        except Exception as e:
                            print(e)
                            pass
                    else:
                        print('File Already Exist',UniqueFileName)
            else:
                print("scheduling jobs")
                schedule.every(1).minutes.do(email_parser)
        print('Downloaded Files of ',ProcessPerameter,MainFileName,UDIDFileName) 
        print(str(path.exists(f'''{currDirPath}\{MainFileName}''')))   
        if str(path.isfile(f'''{currDirPath}\{MainFileName}''')) == 'True':
            if str(path.isfile(f'''{currDirPath}\{MainFileName}''')) == 'True':
                print('Found Main ('+MainFileName +')and UDID ('+UDIDFileName+') File')    
                try:
                    process = subprocess.Popen(['py',f'''{currDirPath}\Automated_process.py''',ProcessPerameter])
                    process.wait()
                except Exception as e:
                    print("Could not open subprocess")
            else:
                print('UDID File Not found')
                schedule.every(1).minutes.do(email_parser)
        else:
            print('Main file Not Found')
            schedule.every(1).minutes.do(email_parser)

if __name__ == "__main__":
    try:
        email_parser()           
    except Exception as e:
        print("error in func")
        # schedule.every(1).minutes.do(email_parser)
        # print(e)
        sendEmailresponse = sendEmail3.sendEmail(EmailSubject,str(e))
        print(sendEmailresponse)
        success = 0
        isEmail = 1
        LogFile_response = Task_Log(TaskDescID,TaskRunDate,success,isEmail,EmailSubject,EmailTo,EmailFrom,str(e))
        print(LogFile_response)
while True:
    schedule.run_pending()
    time.sleep(1)