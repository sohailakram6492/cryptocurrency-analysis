import pyodbc
import os
import glob
import re
import sys
from datetime import datetime, timedelta
import os.path
from sendEmail3 import sendEmail
import sendEmail3

# driver='DRIVER={SQL Server}'
# server='sql-looker-db.database.windows.net'
# database='Looker_live'
# uid='atg-admin'
# pwd='Travel@123'

# con = pyodbc.connect('Driver={SQL Server Native Client 11.0};'
#                     "Server=sql-looker-db.database.windows.net;"
#                     "Database=Looker_live;"
#                     "uid=atg-admin;pwd=Travel@123;")
# cursor = con.cursor()
try:
    # con = pyodbc.connect('%s;SERVER=%s;DATABASE=%s;UID=%s;PWD=%s' % (driver, server,database, uid, pwd))
    # cursor = con.cursor()
    con = pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                    "Server=sql-looker-db.database.windows.net;"
                    "Database=Looker_live;"
                    "uid=atg-admin;pwd=Travel@123;")
    cursor = con.cursor()
    print('Connection Created Log File')
except Exception as e:
    # sendEmailresponse = sendEmail3.sendEmail('Error when Save Task Log',str(e))
    # print(sendEmailresponse)
    print(e)
    exit()
TaskDescID = 1
TaskRunDate = '2020-12-03 05:00:00' # %Y-%m-%d %H:%i:%s
Success = 1
isEmail = 1
EmailSubject = 'Wargaming Text File Error Python2'
EmailTo = 'yshaukat.up@gmail.com'
EmailFrom = 'noreply@atgtravel.com'
EmailBody = 'Exception ro Success'
def guess_date(string):
    for fmt in ["%Y/%m/%d", "%d-%m-%Y", "%Y%m%d", "%Y-%m-%d", "%m/%d/%Y"]:
        try:
            return datetime.strptime(string, fmt).date()
        except ValueError:
            continue
    raise ValueError(string)
def Task_Log(TaskDescID,TaskRunDate,Success,isEmail,EmailSubject,EmailTo,EmailFrom,EmailBody,CreationFileName='',FileCreated='',FileUploaded=''):
    # try:
    CurrentDateTime = format(datetime.now())
    # date_time_str = '2018-06-29 08:15:27.243860'
    # dateFormat = guess_date('12/15/2020')
    # print(dateFormat.strftime("%Y-%m-%d"))
    # date_time_obj = datetime.strptime(date_time_str, '%Y-%m-%d %H:%M:%S.%f')
    # print(CurrentDateTime,date_time_obj)
    # res = cursor.execute('''
    # INSERT INTO Task_Log (TaskDesc_ID, TaskRunDate, TaskCompleteDate , Success ,isEmail , EmailSubject , EmailTo, EmailFrom, EmailBody, AddTime,CreationFileName,FileCreated,FileUploaded) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    # ''', TaskDescID,TaskRunDate,CurrentDateTime,Success,isEmail,EmailSubject,EmailTo,EmailFrom,EmailBody,CurrentDateTime,CreationFileName,FileCreated,FileUploaded)
    sql = "INSERT INTO Task_Log (TaskDesc_ID, TaskRunDate, TaskCompleteDate , Success ,isEmail , EmailSubject , EmailTo, EmailFrom, EmailBody, AddTime) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    val = (TaskDescID,TaskRunDate,CurrentDateTime,Success,isEmail,EmailSubject,EmailTo,EmailFrom,EmailBody,CurrentDateTime)
    cursor.execute(sql, val)
    cursor.commit()

    # con.commit()
    return 'LogSave'
    # except Exception as e:
    #     # Print any error messages to stdout
    #     sendEmailresponse = sendEmail3.sendEmail('Error when Save Task Log',str(e))
    #     print(sendEmailresponse)
    #     return e

if __name__ == "__main__":
	Task_Log(TaskDescID,TaskRunDate,Success,isEmail,EmailSubject,EmailTo,EmailFrom,EmailBody)