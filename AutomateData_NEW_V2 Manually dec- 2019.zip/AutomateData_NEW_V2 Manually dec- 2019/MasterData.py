from pandas.core.indexing import IndexSlice
import pyodbc
import pandas as pd
import csv
import numpy as np
import chardet
import sys
# reload(sys)
# sys.setdefaultencoding('utf-8')
# Shows all columns
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

# ########Connect to database start here########
cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=sql-looker-db.database.windows.net;"
                         "Database=Looker_live;" 
                         "uid=atg-admin;pwd=Travel@123;")
cursor = cnxnLive.cursor()


def master_data(table,StartDate,EndDate,ProcessPerameter):
    try:
        print('---------Inserting Append_v8_NEW data into MASTERDATA--------------')
        # df = pd.read_excel(mycsv)
        # exit()
        # append_query = pd.read_sql_query("SELECT * FROM Append_v8 WHERE invdate between '"+StartDate+"' and '"+EndDate+"'", cnxnLive)
        if ProcessPerameter == 'Monthly':
            df = pd.read_sql_query("SELECT * FROM Append_v8_NEW WHERE invdate between '"+StartDate+"' and '"+EndDate+"' and ProcessFile='M' ", cnxnLive)
        else:
            df = pd.read_sql_query("SELECT * FROM Append_v8_NEW WHERE invdate between '"+StartDate+"' and '"+EndDate+"' and ProcessFile='W' ", cnxnLive)
        
        # df1.columns = ['Client', 'reckey', 'invdate', 'Leg_Counter', 'Spend_Type', 'Spend', 'Spend_USD', 'Spend_EUR', 'AIR_USDRATE', 'AIR_EURORATE', 'AIR_LOCALRATE', 'RAIL_USDRATE', 'RAIL_EURORATE', 'RAIL_LOCALRATE', 'HOTEL_USDRATE', 'HOTEL_EURORATE', 'HOTEL_LOCALRATE', 'CAR_USDRATE', 'CAR_EURORATE', 'CAR_LOCALRATE', 'SSVCFEE_USDRATE', 'SSVCFEE_EURORATE', 'SSVCFEE_LOCALRATE', 'Count_Air', 'Count_Rail', 'Count_Hotel', 'Count_Car', 'Count_Service', 'Total_Count', 'AIRCHG', 'AIRMONEYTYPE', 'HOTELBOOKRATE', 'HMONEYTYPE', 'CARBOOKRATE', 'CARMONEYTYPE', 'SSVCFEE', 'SMONEYTYP', 'AIRLOCALRATE', 'AIREURORATE', 'AIRUSDRATE', 'HOTELLOCALRATE', 'HOTELEURORATE', 'HOTELUSDRATE', 'CARLOCALRATE', 'CAREURORATE', 'CARUSDRATE', 'SSVCFEELOCALRATE', 'SSVCFEEEURORATE', 'SSVCFEEUSDRATE', 'account', 'invoice', 'acct', 'agentid', 'branch', 'pseudocity', 'bookdate', 'valcarr', 'ticket', 'passlast', 'passfrst', 'stndchg', 'mktfare', 'offrdchg', 'reascode', 'AIRCHARGE', 'basefare', 'faretax', 'svcfee', 'trips_cred', 'cardnum', 'recloc', 'domintl', 'trantype', 'break_1', 'break_2', 'break_3', 'depdate', 'arrdate', 'refundable', 'savingcode', 'acommisn', 'tourcode', 'tickettype', 'moneytype', 'exchange', 'origticket', 'tax1', 'tax2', 'tax3', 'tax4', 'iatanbr', 'tkagent', 'bkagent', 'valcarmode', 'gds', 'employeeid', 'booking_nu', 'rplusmin', 'chaincod', 'hotelchain', 'hotcity', 'hotstate', 'metro', 'datein', 'checkout', 'nights', 'rooms', 'number_of_', 'roomtype', 'bookrate', 'HotelMoneyType', 'hotel_plus', 'hotphone', 'hcommissn', 'reascodh', 'hexcpcost', 'hinvbyagcy', 'confirmno', 'hotsvgcode', 'hotstdrate', 'hottrantyp', 'hoteladdr1', 'hoteladdr2', 'hotelzip', 'hotctrycod', 'source', 'hotpropid', 'company', 'autocity', 'autostat', 'citycode', 'rentdate', 'returndate', 'days', 'abookrat', 'cartype', 'ratetype', 'amoneytype', 'car_plusmi', 'ccommisn', 'car_code', 'reascoda', 'aexcprat', 'cinvbyagcy', 'aconfirmno', 'carsvgcode', 'carstdrate', 'cartrantyp', 'airline', 'origin', 'destinat', 'rdepdate', 'rdepdttim', 'rarrdate', 'rarrdttim', 'class', 'farebase', 'fltno', 'seqno', 'segment_no', 'connect', 'actfare', 'segamt', 'miles', 'mode', 'r_plusmin', 'ditcode', 'tktdesig', 'orgctrycod', 'dstctrycod', 'flduration', 'svccode', 'sdescript', 'ServiceFee', 'serviceNoneyType', 'strandate', 'vendorcode', 'stax1', 'stax2', 'stax3', 'stax4', 'sftrantype', 'sf_credit_', 'scardnum', 'smco', 'plusmin', 'legplusmin', 'CLASSCTNAM', 'hotreasn', 'requester', 'OnlineMarker', 'AgentAssistMarker', 'ManualChangeMarker', 'TouchedIndicator', 'OnlineTouchless', 'tripmiles', 'legrouting', 'triporigin', 'triporgcod', 'trporgctry', 'trporgrgn', 'tripdest', 'tripdstcod', 'trpdstctry', 'trpdstrgn', 'trpclascat', 'trpclasdsc', 'classcat', 'regionContinent', 'domintl_new']
        # df.columns = ['Client', 'reckey', 'invdate', 'Leg_Counter', 'Spend_Type', 'Spend', 'Spend_USD', 'Spend_EUR', 'AIR_USDRATE', 'AIR_EURORATE', 'AIR_LOCALRATE', 'RAIL_USDRATE', 'RAIL_EURORATE', 'RAIL_LOCALRATE', 'HOTEL_USDRATE', 'HOTEL_EURORATE', 'HOTEL_LOCALRATE', 'CAR_USDRATE', 'CAR_EURORATE', 'CAR_LOCALRATE', 'SSVCFEE_USDRATE', 'SSVCFEE_EURORATE', 'SSVCFEE_LOCALRATE', 'Count_Air', 'Count_Rail', 'Count_Hotel', 'Count_Car', 'Count_Service', 'Total_Count', 'AIRCHG', 'AIRMONEYTYPE', 'HOTELBOOKRATE', 'HMONEYTYPE', 'CARBOOKRATE', 'CARMONEYTYPE', 'SSVCFEE', 'SMONEYTYP', 'AIRLOCALRATE', 'AIREURORATE', 'AIRUSDRATE', 'HOTELLOCALRATE', 'HOTELEURORATE', 'HOTELUSDRATE', 'CARLOCALRATE', 'CAREURORATE', 'CARUSDRATE', 'SSVCFEELOCALRATE', 'SSVCFEEEURORATE', 'SSVCFEEUSDRATE', 'account', 'invoice', 'acct', 'agentid', 'branch', 'pseudocity', 'bookdate', 'valcarr', 'ticket', 'passlast', 'passfrst', 'stndchg', 'mktfare', 'offrdchg', 'reascode', 'AIRCHARGE', 'basefare', 'faretax', 'svcfee', 'trips_cred', 'cardnum', 'recloc', 'domintl', 'trantype', 'break_1', 'break_2', 'break_3', 'depdate', 'arrdate', 'refundable', 'savingcode', 'acommisn', 'tourcode', 'tickettype', 'moneytype', 'exchange', 'origticket', 'tax1', 'tax2', 'tax3', 'tax4', 'iatanbr', 'tkagent', 'bkagent', 'valcarmode', 'gds', 'employeeid', 'booking_nu', 'rplusmin', 'chaincod', 'hotelchain', 'hotcity', 'hotstate', 'metro', 'datein', 'checkout', 'nights', 'rooms', 'number_of_', 'roomtype', 'bookrate', 'HotelMoneyType', 'hotel_plus', 'hotphone', 'hcommissn', 'reascodh', 'hexcpcost', 'hinvbyagcy', 'confirmno', 'hotsvgcode', 'hotstdrate', 'hottrantyp', 'hoteladdr1', 'hoteladdr2', 'hotelzip', 'hotctrycod', 'source', 'hotpropid', 'company', 'autocity', 'autostat', 'citycode', 'rentdate', 'returndate', 'days', 'abookrat', 'cartype', 'ratetype', 'amoneytype', 'car_plusmi', 'ccommisn', 'car_code', 'reascoda', 'aexcprat', 'cinvbyagcy', 'aconfirmno', 'carsvgcode', 'carstdrate', 'cartrantyp', 'airline', 'origin', 'destinat', 'rdepdate', 'rdepdttim', 'rarrdate', 'rarrdttim', 'class', 'farebase', 'fltno', 'seqno', 'segment_no', 'connect', 'actfare', 'segamt', 'miles', 'mode', 'r_plusmin', 'ditcode', 'tktdesig', 'orgctrycod', 'dstctrycod', 'flduration', 'svccode', 'sdescript', 'ServiceFee', 'serviceNoneyType', 'strandate', 'vendorcode', 'stax1', 'stax2', 'stax3', 'stax4', 'sftrantype', 'sf_credit_', 'scardnum', 'smco', 'plusmin', 'legplusmin', 'CLASSCTNAM', 'hotreasn', 'requester', 'OnlineMarker', 'AgentAssistMarker', 'ManualChangeMarker', 'TouchedIndicator', 'OnlineTouchless', 'tripmiles', 'legrouting', 'triporigin', 'triporgcod', 'trporgrgn', 'tripdest', 'tripdstcod', 'trpdstrgn', 'trpclascat', 'trpclasdsc', 'classcat', 'regionContinent','domintl_new']

        df.columns = [x.upper() for x in df.columns]
        df['INVDATE'] = pd.to_datetime(df['INVDATE'], errors='coerce')
        df['BOOKDATE'] = pd.to_datetime(df['BOOKDATE'], errors='coerce')
        df['DEPDATE'] = pd.to_datetime(df['DEPDATE'], errors='coerce')
        df['ARRDATE'] = pd.to_datetime(df['ARRDATE'], errors='coerce')
        df['DATEIN'] = pd.to_datetime(df['DATEIN'], errors='coerce')
        df['CHECKOUT'] = pd.to_datetime(df['CHECKOUT'], errors='coerce')
        df['RENTDATE'] = pd.to_datetime(df['RENTDATE'], errors='coerce')
        df['RETURNDATE'] = pd.to_datetime(df['RETURNDATE'], errors='coerce')
        df['RDEPDATE'] = pd.to_datetime(df['RDEPDATE'], errors='coerce')
        df['RARRDATE'] = pd.to_datetime(df['RARRDATE'], errors='coerce')
        df['STRANDATE'] = pd.to_datetime(df['STRANDATE'], errors='coerce')

        df = df.replace("'",' ',regex=True)
        header = df.columns.tolist()
        headers = map((lambda x: x.strip()), header)
        
        insert = 'INSERT INTO {} ('.format(table) + ', '.join(headers) + ') VALUES '
        df['uploaded']=['0']*df.shape[0]
        print(df['uploaded'])
        
        rowCount = 1
        for i,row in df.iterrows():
            values = map((lambda x: "'"+str(x)+"'"), row[:-1])
            inserting = insert +'('+ ', '.join(values) +');'
            inserting= inserting.replace("'nan'",'NULL')
            inserting= inserting.replace("'NaT'",'NULL')
            print(inserting)
            cnxnLive.execute(inserting )
            print('Inerted Records' + str(rowCount))
            rowCount = rowCount +1
            df.loc[i, 'uploaded'] = "1"
        cnxnLive.commit()

        return 'MasterData Success'
    except:
        e = sys.exc_info()
        return e


if __name__ == "__main__":
	# master_data()
	Response = master_data('MASTERDATA_NEW', '2018-09-01', '2018-09-10', 'monthly')
	print(Response)