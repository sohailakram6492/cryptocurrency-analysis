import datetime
import sys

ProcessPerameter = sys.argv[1]
print('Running '+ ProcessPerameter + ' Data')
today = datetime.date.today()
print(today)
#today = datetime.date('2020-12-29')
date_time_str = '2021-01-06'
date_time_obj = datetime.datetime.strptime(date_time_str, '%Y-%m-%d')
print(date_time_obj.strftime("%m/%d/%Y"))
last_monday = date_time_obj - datetime.timedelta(days=date_time_obj.weekday()+7)
last_sunday = date_time_obj - datetime.timedelta(days=date_time_obj.weekday()+1)
print("Today:", date_time_obj.strftime("%m/%d/%Y"))
print("Last Monday:", last_monday.strftime("%m/%d/%Y"))
print("Last Sunday:", last_sunday.strftime("%m/%d/%Y"))
print("Last Week Number:",  last_sunday.strftime("%Y%m%U"))
print("Last Week Number:",  last_monday.strftime("%m%d%Y"))
FileName = last_monday.strftime("%m%d%Y") + '-'+last_sunday.strftime("%m%d%Y") +'.xlsx'
print(FileName)

import smtplib
import zipfile
import tempfile
from email import encoders
from email.message import Message
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart    
# with open("D:/python/MissingData/File2.txt", "w") as f:   # Opens file and casts as f 
#     f.write("First day of prev month:"+date_time_obj.strftime("%m/%d/%Y"))          
#     f.write("\nLast Monday:"+last_monday.strftime("%m/%d/%Y"))   
def send_file_zipped(the_file, recipients, sender='noreply@atgtravel.com'):
    zf = tempfile.TemporaryFile(prefix='mail', suffix='.zip')
    zip = zipfile.ZipFile(zf, 'w')
    zip.write(the_file)
    zip.close()
    zf.seek(0)

    # Create the message
    themsg = MIMEMultipart()
    themsg['Subject'] = 'File %s' % the_file
    themsg['To'] = ', '.join(recipients)
    themsg['From'] = sender
    themsg.preamble = 'I am not using a MIME-aware mail reader.\n'
    msg = MIMEBase('application', 'zip')
    msg.set_payload(zf.read())
    encoders.encode_base64(msg)
    msg.add_header('Content-Disposition', 'attachment', 
                   filename=the_file + '.zip')
    themsg.attach(msg)
    themsg = themsg.as_string()

    # send the message
    smtp = smtplib.SMTP()
    smtp.connect()
    smtp.sendmail(sender, recipients, themsg)
    smtp.close()
    print('Email Send: TO:  ',recipients,' FROM:' ,sender)
    """
    # alternative to the above 4 lines if you're using gmail
    server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
    server.login("username", "password")
    server.sendmail(sender,recipients,themsg)
    server.quit()
    """
# send_file_zipped('testfile.txt', ['farhanamjadrehan@gmail.com'])