from MasterData import master_data
import pandas as pd
# import pymssql
import pyodbc
import numpy as np
from itertools import groupby
import mimetypes
from email.mime.multipart import MIMEMultipart
from email import encoders
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.text import MIMEText
import datetime
import time
import logging
import csv
import glob
import re
# from unidecode import unidecode
from dateutil.relativedelta import relativedelta
from Accounts_upload import accounts_upload_
import Accounts_upload
from TransferData import insert_records 
import TransferData
from TransferDataUdids import udid_insert_records
import TransferDataUdids 
from Class_name_insert import class_name_insert_function
import Class_name_insert
from ExchangeRate import exchange_rate_funct
import ExchangeRate
from sendEmail3 import sendEmail
import sendEmail3
import itertools as IT
import sys, os
import datetime
from os import path
from datetime import date, timedelta
from LogFile import Task_Log
import LogFile
from Reading_files import Filesreading
import Reading_files
from MasterData import master_data
import MasterData
from itertools import groupby


# if sys.argv[1]:
#     ProcessPerameter = sys.argv[1]
# else:
#     ProcessPerameter = 'Monthly'
ProcessPerameter = 'Weekly'
today = datetime.date.today()
first = today.replace(day=1)
#Code Copy data from Email
print("Today:", today.strftime("%m/%d/%Y"))
TaskRunDate = today
EmailTo = 'yshaukat.up@gmail.com'
EmailFrom = 'noreply@atgtravel.com'
lastMonth = first - datetime.timedelta(days=1)
date_time_str = str(today)
date_time_obj = datetime.datetime.strptime(date_time_str, '%Y-%m-%d')
# print(date_time_obj.strftime("%m/%d/%Y"))
last_monday = date_time_obj - datetime.timedelta(days=date_time_obj.weekday()+7)
last_sunday = date_time_obj - datetime.timedelta(days=date_time_obj.weekday()+1)
WeeklyFileName = last_monday.strftime("%Y%m%d") + '-'+last_sunday.strftime("%Y%m%d") 

# Manual Process start hrere
ProcessPerameter = 'Monthly'
TaskRunDate = today
EmailTo = 'yshaukat.up@gmail.com'
EmailFrom = 'noreply@atgtravel.com'
MainFileName = 'Merck China dec-2019 MasterTrip.xlsx'
UDIDFileName = 'Merck China dec 2019 UDIDS.xlsx'
StartDate = '2019-12-01'
EndDate = '2019-12-31'
TaskDescID = 12
EmailSubject = 'MasterUDIDMonthlyDataProcess DataBase Connection Eror'
EmailSubject1 = 'MasterUDIDMonthlyDataProcess Script Eror'

TaskRunDate = str(today) + ' 06:00:00'

EmailMsg = ''
if str(path.isfile(MainFileName)) == 'True':
    print('Main file' , MainFileName)
else:
    print('Not Found',str(path.isfile(MainFileName)))
########Connect to database start here########
try:
    cnxnLooker_live = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                            "Server=sql-looker-db.database.windows.net;"
                            "Database=Looker_live;" 
                            "uid=atg-admin;pwd=Travel@123;")
    cursor = cnxnLooker_live.cursor()
except Exception as e:
    print(e)
    # sendEmailresponse = sendEmail3.sendEmail('15th of Month Master and UDID Error',str(e))
    # print(sendEmailresponse)
    # if sendEmailresponse == 'EmailSend':
    #     isEmail = 1
    # else:
    #     isEmail = 0
    # Success = 0
    # EmailBody = 'Could not connect to looker database.'
    # LogFile_response = LogFile.Task_Log(TaskDescID,TaskRunDate,Success,isEmail,EmailSubject,EmailTo,EmailFrom,EmailBody)
    # print(LogFile_response)
    exit()

print(MainFileName)
print(UDIDFileName)
print(StartDate)
print(EndDate)
print(ProcessPerameter)
print(TaskRunDate)
# reading_response = Reading_files.Filesreading(MainFileName,StartDate,EndDate,ProcessPerameter)
# print(reading_response)
MainFileName = str('Updated ')+ MainFileName
print(MainFileName)
# exit()
print(MainFileName)
print(UDIDFileName)

# exit()
try:
    if str(path.isfile(MainFileName)) == 'True' and str(path.isfile(UDIDFileName)) == 'True':
        print('Found Main ('+MainFileName +')and UDID ('+UDIDFileName+') File')
        # accounts_response = Accounts_upload.accounts_upload_()
        accounts_response = 'AccountsUploaded'
        if accounts_response == 'AccountsUploaded':
            print('Accounts Uploaded Successfully')
            # transferData_response = TransferData.insert_records('MasterTrip',MainFileName,StartDate,EndDate)
            transferData_response = 'TranferDataSuccessfully'
            if transferData_response == 'TranferDataSuccessfully':
                print('Main Data Process Successfully')
                # udid_insert_records_response = TransferDataUdids.udid_insert_records('UDIDS',UDIDFileName,StartDate,EndDate)
                udid_insert_records_response = 'UdidDataInsertSuccessfully'
                if udid_insert_records_response == 'UdidDataInsertSuccessfully':
                    print('Udid Data Insert Sucessfully')
                    class_name_insert_function_response = Class_name_insert.class_name_insert_function(MainFileName)
                    # class_name_insert_function_response = 'classNameInsertSuccessfully'
                    if class_name_insert_function_response == 'classNameInsertSuccessfully':
                        print('Class Name Insert Successfullly')
                        exchange_rate_response = ExchangeRate.exchange_rate_funct(StartDate,EndDate,ProcessPerameter)
                        # exchange_rate_response = 'ExchangeRateSuccess'
                        if exchange_rate_response == 'ExchangeRateSuccess':
                            print('Exchange Rate Inserted Successfully')
                            print('\n........Inserting into MasterData from Append_v9........\n')
                            if ProcessPerameter == 'Monthly':
                                sql_query=("INSERT INTO dbo.MASTERDATA select * from Append_V9 where ACCT IN ('MERCKCN11C') AND invdate BETWEEN '"+StartDate+"' and '"+EndDate+"' AND ProcessFile='M'  ")
                                print(sql_query)
                                cursor.execute(sql_query)
                                cursor.commit()
                            else:
                                sql_query=("INSERT INTO dbo.MASTERDATA select * from Append_V9 where ACCT IN ('MERCKCN11C') AND invdate BETWEEN '"+StartDate+"' and '"+EndDate+"' AND ProcessFile='W'  ")
                                print(sql_query)
                                cursor.execute(sql_query)
                                cursor.commit()
                            sendEmailresponse = sendEmail3.sendEmail(ProcessPerameter+ ' Master and UDID Successfully',"Perform All Tasks 1- Accounts Uploaded Successfully \n 2- Main Data Process Successfully \n 3- Udid Data Insert Sucessfully \n 4- Class Name Insert Successfullly \n 5- Exchange Rate Inserted Successfully \n 7- Insert Append_v7 data into MASTERDATA ")
                            print(sendEmailresponse)
                            sendEmailresponse = 'EmailSend'
                            if sendEmailresponse == 'EmailSend':
                                isEmail = 1
                            else:
                                isEmail = 0
                            Success = 1
                            EmailSubject1 = str(ProcessPerameter) + 'Master and UDID data Process Sucessfull'
                            EmailBody= 'Master and UDID data Process Sucessfull '
                            # LogFile_response = LogFile.Task_Log(TaskDescID,TaskRunDate,Success,isEmail,EmailSubject1,EmailTo,EmailFrom,EmailBody)
                            # print(LogFile_response)
                            exit()
                        else:
                            DisplayMessage = 'Exchange Rate Error'
                            EmailMsg = '-1 ' + str(accounts_response)+ '\n -2 ' + str(transferData_response)+ '\n -3 ' + str(udid_insert_records_response) + '\n -4 ' + str(class_name_insert_function_response) + '\n -5 ' + DisplayMessage + str(exchange_rate_response)
                            print(DisplayMessage)
                            print(exchange_rate_response)
                    else:
                        DisplayMessage = 'Class Name Insertion Error'
                        EmailMsg = '-1 ' + str(accounts_response) + '\n -2 ' + str(transferData_response) + '\n -3 ' + str(udid_insert_records_response) + '\n -4 ' + DisplayMessage + str(class_name_insert_function_response)
                        print(DisplayMessage)
                        print(class_name_insert_function_response)
                else:
                    DisplayMessage = 'Udids Data Insertion Error'
                    EmailMsg = '-1 '+ str(accounts_response) + '\n -2 ' + str(transferData_response) + '\n -3 ' + DisplayMessage + str(udid_insert_records_response)
                    print(DisplayMessage)
                    print(udid_insert_records_response)
            else:
                DisplayMessage = 'Main data Do not Process Successfully Error is '
                EmailMsg = '-1 ' + str(accounts_response) + '\n -2 ' + DisplayMessage + str(transferData_response)
                print(DisplayMessage)
                print(transferData_response)
        else:
            print('Accounts not Uploaded')
    elif str(path.isfile(MainFileName)) == 'True':
        EmailMsg = 'Missing UDID ('+UDIDFileName +').Only Main ('+MainFileName+') File exist'
        print(EmailMsg)
    elif str(path.isfile(UDIDFileName)) == 'True':
        EmailMsg = 'Missing Main ('+MainFileName +').Only UDID ('+UDIDFileName+') File exist'
        print(EmailMsg)
    else:
        EmailMsg = 'Missing Main ('+MainFileName +') and UDID ('+UDIDFileName+') File'
        print(EmailMsg)
    if EmailMsg != '':
        # sendEmailresponse = sendEmail3.sendEmail(ProcessPerameter + ' Master and UDID Error',EmailMsg)
        # print(sendEmailresponse)
        print('email send')
        print('not')
except Exception as e:
    # sendEmailresponse = sendEmail3.sendEmail('15th of Month Master and UDID Error',str(e))
    # print(sendEmailresponse)
    # if sendEmailresponse == 'EmailSend':
    #     isEmail = 1
    # else:
    #     isEmail = 0
    # Success = 0
    # EmailBody= 'Could not Process '
    # LogFile_response = LogFile.Task_Log(TaskDescID,TaskRunDate,Success,isEmail,EmailSubject1,EmailTo,EmailFrom,EmailBody)
    # print(LogFile_response)
    print(e)