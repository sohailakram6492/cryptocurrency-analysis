import pyodbc
import pandas as pd
import csv
import numpy as np
import chardet
import sys
# reload(sys)
# sys.setdefaultencoding('utf-8')
# Shows all columns
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

########Connect to database start here########
cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=sql-looker-db.database.windows.net;"
                         "Database=Looker_live;" 
                         "uid=atg-admin;pwd=Travel@123;")


# read database
# DataFileName= 'TCMaster (3-9 May 2021).xlsx'
def class_name_insert_function(DataFileName):
    
    try:
        df = pd.read_excel(DataFileName)
        df.columns = map(str.upper, df.columns)
        df = df[['INVDATE','CLASSCTNAM','RECKEY','PLUSMIN','LEGPLUSMIN','LEGCNTR']]

        df = df.replace("'",' ',regex=True)
        df.reset_index(drop=True, inplace=True)
        # print(df)
        # below code help to not upload the same data again
        ff= open("Unit1.txt", "r")
        rekey_processed = (ff.read())
        rekey_processed = rekey_processed.replace("'","")
        rekey_processed = rekey_processed.replace(" ","")
        rekey_processed = rekey_processed.split(',')
        rekey_processed = list(set(rekey_processed))
        rekey_processed = [s for s in rekey_processed if s != '']
        results = list(map(int, rekey_processed))
        print(df.shape)
        df = df[~ df.RECKEY.isin(rekey_processed) ]
        print(df.shape)
        df.reset_index(drop=True, inplace=True)
        ff.close()

        for i , row in df.iterrows():
            df2 = df[df.RECKEY == row['RECKEY']]
            CLASSCTNAM = list(set(df2.CLASSCTNAM.to_list()))
            CLASSCTNAM = [ x for x in CLASSCTNAM if pd.notnull(x) ]
            results = (' , '.join(CLASSCTNAM))
            results= results.replace('[','')
            results= results.replace(']','')
            if results == '':
                results =np.nan
            df.loc[df.RECKEY == row['RECKEY'],'CLASSCTNAM'] =results


        # remove any null value from CLASSCTNAM and reset the index
        df = df[~pd.isnull(df.CLASSCTNAM)]
        df.reset_index(drop=True, inplace=True)

        ########Connect to database start here########
        # cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
        #                         "Server=sql-looker-db.database.windows.net;"
        #                         "Database=Looker_live;" 
        #                         "uid=atg-admin;pwd=Travel@123;")


        f= open("Unit1.txt","a+")
        for region, df_region in df.groupby(['CLASSCTNAM','LEGCNTR']):
            print(region)
            xx = True
            ix = 0
            while xx :
                ix2 = 200 + ix
                if ix2 > df_region.shape[0]:
                    xx= False
                    ix2 = df_region.shape[0]
                print(ix, ix2)
                strg = df_region.RECKEY[ix:ix2]
                list_string = map(str, strg)
                list_string = list(list_string)
                list_string2 = str(list_string)
                list_string = list_string2.replace('[','(')
                list_string = list_string.replace(']', ');')
                stri = "Update MasterTrip set [CLASSCTNAM] = '{}' where LEGCNTR ='{}' and  " \
                    "reckey in {}".format(region[0],region[1],list_string + "\r\n")
                print(stri)
                cnxnLive.execute(stri)
                
                list_string2 = list_string2.replace('[',' , ')
                list_string2 = list_string2.replace(']',' , ')
                #f.write(list_string2)
                ix+= 200
            cnxnLive.commit()

        f.close()
        return 'classNameInsertSuccessfully'
    except Exception as e:
        e = sys.exc_info()
        print(e)
        return e
if __name__ == "__main__":
    class_name_insert_function()
    # class_name_insert_function('TCMaster (3-9 May 2021).xlsx')



