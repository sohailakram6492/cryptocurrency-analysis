import pyodbc
import pandas as pd
import datetime
from datetime import datetime
import sys
# reload(sys)
# sys.setdefaultencoding('utf-8')
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

def accounts_upload_():
    print("\n----------------Accounts Upload Script Function--------------------\n")
    try:
        
        ########Connect to database start here########
        cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                                "Server=atg-dev.database.windows.net;"
                                "Database=atgdevdb;" 
                                "uid=atg-admin;pwd=dev13579*;")

        cnxnLive_Bi = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                                "Server=sql-looker-db.database.windows.net;"
                                "Database=Looker_live;" 
                                "uid=atg-admin;pwd=Travel@123;")



        # cursorLive = cnxnLive.cursor()
        # cursorLive_bi = cnxnLive_Bi.cursor()
        # csr = cnxnLive.cursor()  
        # csr.close()
        # cnxnLive.close()
        # del csr
        #######Connect to database end here########

        # Get TCACCTS most updated results results.
        TcacctsLive = pd.read_sql_query('''SELECT *  FROM globalAccounts_globalaccount ''', cnxnLive)
        TcacctsLive.columns =  TcacctsLive.columns.str.lower()

        # Get [MasterAccount] data from Looker_live database
        MasterAccount = pd.read_sql_query('''SELECT *  FROM  MasterAccount  ''', cnxnLive_Bi)
        MasterAccount.columns = MasterAccount.columns.str.lower()

        # remove any column not in MasterAccount from TcacctsLive
        TcacctsLive = TcacctsLive[MasterAccount.columns.str.lower()]

        # filter the data not in MasterAccount table
        TcacctsLive = TcacctsLive[~TcacctsLive.aian_dk.isin(MasterAccount.aian_dk)]

        # insert the new accounts to MasterAccount table
        header = TcacctsLive.columns.tolist()
        headers = map((lambda x: x.strip()), header)
        insert = 'INSERT INTO {} ('.format('MasterAccount') + ', '.join(headers) + ') VALUES '
        # try:
        print("**********************Inserting into MasterAccount**************************")
        for i,row in TcacctsLive.iterrows():
            values = map((lambda x: "'"+str(x)+"'"), row )
            inserting = insert +'('+ ', '.join(values) +');'
            # print(inserting)
            inserting= inserting.replace("'nan'",'NULL')
            inserting= inserting.replace("'NaT'",'NULL')
            print(inserting )
            cnxnLive_Bi.execute(inserting )
            cnxnLive_Bi.commit()
        return 'AccountsUploaded'
    except:
        return 'AccountsError'
if __name__ == "__main__":
	accounts_upload_()