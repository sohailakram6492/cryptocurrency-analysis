import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from os.path import basename


def sendEmail(subject,message,FileName=None):
    port = 587  # For SSL
    smtp_server = "smtp.office365.com"
    sender_email = "noreply@atgtravel.com"  # Enter your address
    receiver_email = "yshaukat.up@gmail.com"  # Enter receiver address
    password = "guTaYxdaNLBV*Sks86LpsRD4huy3BzA2*j&g7Hv^"
    # message = """\
    # Subject: """ + subject + """

    # # """+msg
    # print(str(message))
    # msg = MIMEMultipart()
    # msg['Subject'] = str(subject)

    body = str(message)
    # msg.attach(MIMEText(body,'plain'))

    # text = msg.as_string()
    # Create a secure SSL context

    # Try to log in to server and send email
    try:
        message = MIMEMultipart()
        message['From'] = sender_email
        message['To'] = receiver_email
        message['Subject'] = str(subject)
        #The subject line
        #The body and the attachments for the mail
        message.attach(MIMEText(body, 'plain'))
        if FileName is not None:
            attach_file = open(FileName, 'rb') # Open the file as binary mode
            payload = MIMEBase('application', 'octate-stream')
            payload.set_payload((attach_file).read())
            encoders.encode_base64(payload) #encode the attachment
            #add payload header with filename
            payload.add_header('Content-Disposition', "attachment; filename= %s" % basename(FileName))
            print(FileName)
            message.attach(payload)
        text = message.as_string()
        context = ssl.create_default_context()
        server = smtplib.SMTP(smtp_server,port)
        server.ehlo() # Can be omitted
        server.starttls(context=context) # Secure the connection
        server.ehlo() # Can be omitted
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, text)
        # TODO: Send email here
        server.quit() 
        return 'EmailSend'
    except Exception as e:
        # Print any error messages to stdout
        print(e)

if __name__ == "__main__":
	sendEmail()