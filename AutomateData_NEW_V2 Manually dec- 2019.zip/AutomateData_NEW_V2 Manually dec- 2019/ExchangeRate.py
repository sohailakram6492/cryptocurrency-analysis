import pyodbc
import pandas as pd
import csv
import numpy as np
import chardet
import sys,os
# Shows all columns
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

from datetime import datetime
# from forex_python.converter import get_rate

########Connect to database start here########
cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=sql-looker-db.database.windows.net;"
                         "Database=Looker_live;" 
                         "uid=atg-admin;pwd=Travel@123;")
cursor = cnxnLive.cursor()


# conect to Rates_Live table
cnxnLive_Bi = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=sql-looker-db.database.windows.net;"
                         "Database=Looker_live;" 
                         "uid=atg-admin;pwd=Travel@123;")
# def rateLiveQuery(StartDate,EndDate):
#     sql_query='''SELECT * FROM  Rates_Live  where [Date] like '2020-12%' '''
#     result = pd.read_sql_query(sql_query, cnxnLive_Bi)
#     return result

def get_rate(curency,convert_to_currency, invoice_date,result):
    cnxnLive_Bi = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=sql-looker-db.database.windows.net;"
                         "Database=Looker_live;" 
                         "uid=atg-admin;pwd=Travel@123;")

    temp=result[(result['Base']==convert_to_currency) & (result['Date']== pd.to_datetime((invoice_date), format='%Y-%m-%d'))][curency].values[0]
    if temp:
        return round(float(1 / float(temp)),4)
    else:
        print("***************************Executing query************************************")
        sql_query='''SELECT [{}]  FROM  Rates_Live  where Base = '{}' and [Date] ='{}' '''.format(curency,convert_to_currency,invoice_date )
        curency = pd.read_sql_query(sql_query, cnxnLive_Bi)
        # print(curency)
        return round(float(1 / float(curency.iloc[0][0])),4)
def exchange_rate_funct(StartDate,EndDate,ProcessPerameter):
    print("\n----------------Start Exchange Rate Insertion Script Function--------------------\n")
    try:
        if ProcessPerameter == 'Monthly':
            Trips = pd.read_sql_query("SELECT *   FROM MasterTrip  WHERE ACCT IN ('MERCKCN11C') AND invdate BETWEEN '"+StartDate+"' and '"+EndDate+"' and ProcessFile='M' ", cnxnLive)
        else:
            Trips = pd.read_sql_query("SELECT *   FROM MasterTrip  WHERE ACCT IN ('MERCKCN11C') AND invdate BETWEEN '"+StartDate+"' and '"+EndDate+"' and ProcessFile='W' ", cnxnLive)
        print(Trips)
        Trips.columns = [x.upper() for x in Trips.columns]
    

        sql_query="SELECT * FROM  Rates_Live WHERE [Date] BETWEEN '"+StartDate+"' AND '"+EndDate+"' "
        resultRatesLive = pd.read_sql_query(sql_query, cnxnLive_Bi)
        # extract the month day and year from invdate
        Trips['INVDATE'] = pd.to_datetime(Trips['INVDATE'], format='%Y-%m-%d')
        Trips['YEAR'] = Trips['INVDATE'].dt.year
        Trips['MONTH'] = Trips['INVDATE'].dt.month
        Trips['DAY'] = Trips['INVDATE'].dt.day

        # below code will help to not insert the same data twice
        Reckey = pd.read_sql_query('''SELECT RECKEY,LEGCNTR FROM Rate_Exchange ''', cnxnLive)
        Reckey['recleg'] = Reckey['RECKEY'].apply(str) +'_' + Reckey['LEGCNTR'].apply(str)
        Trips['recleg'] = Trips['RECKEY'].apply(str) +'_' + Trips['LEGCNTR'].apply(str)
        Trips['recleg'] = Trips['recleg'].str.split('.').str[0]
        Trips = Trips[~Trips.recleg.isin(Reckey['recleg'])]
        del Trips['recleg']
        
        Trips = Trips.fillna(value=np.nan)
        print(Trips)
        # loop throwgh trips table and convert the spends
        
        count = 1
        for i, row in Trips.iterrows():
            if row['RECKEY'] == 1:
                continue
            # print('RECKEY',row['RECKEY'])
            RECKEY =int(float(row['RECKEY']))
            AIRCHG =float(row['AIRCHG'])
            AIRMONEYTYPE =row['MONEYTYPE']
            HOTELBOOKRATE =float(row['BOOKRATE'])
            HMONEYTYPE =row['HMONEYTYPE']
            CARBOOKRATE =float(row['ABOOKRAT'])
            if np.isnan(CARBOOKRATE):
                CARBOOKRATE = None
            CARMONEYTYPE =row['AMONEYTYPE']
            SSVCFEE =float(row['SSVCFEE'])
            SMONEYTYP =row['SMONEYTYP']
            AIRLOCALRATE =float(row['AIRCHG'])
            AIREURORATE =0.0
            AIRUSDRATE =0.0
            HOTELLOCALRATE =float(row['BOOKRATE'])
            HOTELEURORATE =0.0
            HOTELUSDRATE =0.0
            CARLOCALRATE =float(row['ABOOKRAT'])
            CAREURORATE =0.0
            CARUSDRATE =0.0
            SSVCFEELOCALRATE =float(row['SSVCFEE'])
            SSVCFEEEURORATE =0.0
            SSVCFEEUSDRATE =0.0
            LEGCNTR = int(float(row['LEGCNTR']))
            Converted ='1'
            try:
                # check if invdate is empty and replace it with the same reckey leg one
                if pd.isnull(row['INVDATE'] ):
                    InvdateData = Trips[Trips.RECKEY == row['RECKEY']]
                    InvdateData['YEAR'] = InvdateData['INVDATE'].dt.year
                    InvdateData['MONTH'] = InvdateData['INVDATE'].dt.month
                    InvdateData['DAY'] = InvdateData['INVDATE'].dt.day
                    row['YEAR'] =InvdateData.iloc[0]['YEAR']
                    row['MONTH'] =InvdateData.iloc[0]['MONTH']
                    row['DAY'] =InvdateData.iloc[0]['DAY']

                t = datetime(int(row['YEAR']),int(row['MONTH']) ,int(row['DAY'] ))
                t = t.strftime('%Y-%m-%d')
                # Convert air spends
                # print("AIRCHG: ",row['AIRCHG'])
                if float(row['AIRCHG']) > 0  or float(row['AIRCHG']) < 0:
                    if row['MONEYTYPE'] == 'USD' :
                        AIRUSDRATE = row['AIRCHG']
                        rate_EUR = get_rate(row['MONEYTYPE'], "EUR" ,t,resultRatesLive)
                        AIREURORATE = rate_EUR *row['AIRCHG']
                        AIREURORATE = round(AIREURORATE,2)
                        # print('AIREURORATE: ', AIREURORATE)
                    elif row['MONEYTYPE'] == 'EUR' :
                        AIREURORATE = row['AIRCHG']
                        rate_USD = get_rate(row['MONEYTYPE'], "USD" ,t,resultRatesLive)
                        AIRUSDRATE = rate_USD *row['AIRCHG']
                        AIRUSDRATE = round(AIRUSDRATE,2)
                        # print('AIRUSDRATE: ', AIRUSDRATE)
                    else:
                        # convert to USD
                        # print("inside else:")
                        AIRLOCALRATE = row['AIRCHG']
                        # print('AIRLOCALRATE: ',AIRLOCALRATE)
                        rate_USD = get_rate(row['MONEYTYPE'], "USD" ,t,resultRatesLive)
                        # print("rate_USD",rate_USD)
                        AIRUSDRATE = rate_USD *row['AIRCHG']
                        AIRUSDRATE = round(AIRUSDRATE,2)
                        # print('AIRUSDRATE: ',AIRUSDRATE)
                    
                        # convert to EUR
                        AIRLOCALRATE = row['AIRCHG']
                        # print('AIRLOCALRATE: ',AIRLOCALRATE)
                        rate_EUR = get_rate(row['MONEYTYPE'], "EUR" ,t,resultRatesLive)
                        # print("rate_EUR",rate_EUR)
                        AIREURORATE = rate_EUR *row['AIRCHG']
                        AIREURORATE = round(AIREURORATE,2)
                        # print('AIREURORATE: ',AIREURORATE)

                # convert hotel spends
                # print("BOOKRATE: ",row['BOOKRATE'])
                if float(row['BOOKRATE']) >  0 or float(row['BOOKRATE']) <0 :
                    if row['HMONEYTYPE'] == 'USD' :
                        HOTELUSDRATE = float(row['BOOKRATE'])
                        rate_EUR = get_rate(row['HMONEYTYPE'], "EUR" ,t,resultRatesLive)
                        HOTELEURORATE = rate_EUR *float(row['BOOKRATE'])
                        HOTELEURORATE = round(HOTELEURORATE,2)
                        # print('HOTELEURORATE: ', HOTELEURORATE)
                    elif row['HMONEYTYPE'] == 'EUR' :
                        HOTELEURORATE = float(row['BOOKRATE'])
                        rate_USD = get_rate(row['HMONEYTYPE'], "USD" ,t,resultRatesLive)
                        HOTELUSDRATE = rate_USD *float(row['BOOKRATE'])
                        HOTELUSDRATE = round(HOTELUSDRATE,2)
                        # print('HOTELUSDRATE: ', HOTELUSDRATE)
                    else:
                        # convert to USD
                        HOTELLOCALRATE =float( row['BOOKRATE'])
                        rate_USD = get_rate(row['HMONEYTYPE'], "USD" ,t,resultRatesLive)
                        HOTELUSDRATE = rate_USD *float(row['BOOKRATE'])
                        HOTELUSDRATE = round(HOTELUSDRATE,2)
                        # convert to EUR
                        HOTELLOCALRATE = float(row['BOOKRATE'])
                        rate_EUR = get_rate(row['HMONEYTYPE'], "EUR" ,t,resultRatesLive)
                        HOTELEURORATE = rate_EUR *float(row['BOOKRATE'])
                        HOTELEURORATE = round(HOTELEURORATE,2)
                # convert cars spends
                # print('ABOOKRAT: ', row['ABOOKRAT'])
                if float(row['ABOOKRAT']) > 0 or float(row['ABOOKRAT']) <0 :
                    if row['AMONEYTYPE'] == 'USD' :
                        CARUSDRATE = float(row['ABOOKRAT'])
                        rate_EUR = get_rate(row['AMONEYTYPE'], "EUR" ,t,resultRatesLive)
                        CAREURORATE = rate_EUR *float(row['ABOOKRAT'])
                        CAREURORATE = round(CAREURORATE,2)
                        # print('CAREURORATE: ', CAREURORATE)
                    elif row['AMONEYTYPE'] == 'EUR' :
                        CAREURORATE = float(row['ABOOKRAT'])
                        rate_USD = get_rate(row['AMONEYTYPE'], "USD" ,t,resultRatesLive)
                        CARUSDRATE = rate_USD *float(row['ABOOKRAT'])
                        CARUSDRATE = round(CARUSDRATE,2)
                        # print('CARUSDRATE: ', CARUSDRATE)
                    else:
                        # convert to USD
                        CARLOCALRATE =float( row['ABOOKRAT'])
                        # print ('CARLOCALRATE: ',CARLOCALRATE)
                        rate_USD = get_rate(row['AMONEYTYPE'], "USD" ,t,resultRatesLive)
                        CARUSDRATE = rate_USD *float(row['ABOOKRAT'])
                        CARUSDRATE = round(CARUSDRATE,2)
                        # convert to EUR
                        CARLOCALRATE = float(row['ABOOKRAT'])
                        # print ('CARUSDRATE: ',CARUSDRATE)
                        rate_EUR = get_rate(row['AMONEYTYPE'], "EUR" ,t,resultRatesLive)
                        CAREURORATE = rate_EUR *float(row['ABOOKRAT'])
                        CAREURORATE = round(CAREURORATE,2)
                # convert Services spends
                # print('SSVCFEE: ',row['SSVCFEE'])
                if float(row['SSVCFEE']) > 0 or float(row['SSVCFEE']) <0 :
                    if row['SMONEYTYP'] == 'USD' :
                        SSVCFEEUSDRATE = float(row['SSVCFEE'])
                        rate_EUR = get_rate(row['SMONEYTYP'], "EUR" ,t,resultRatesLive)
                        SSVCFEEEURORATE = rate_EUR *float(row['SSVCFEE'])
                        SSVCFEEEURORATE = round(SSVCFEEEURORATE,2)
                        # print('SSVCFEEEURORATE: ', SSVCFEEEURORATE)
                    elif row['SMONEYTYP'] == 'EUR' :
                        SSVCFEEEURORATE = float(row['SSVCFEE'])
                        rate_USD = get_rate(row['SMONEYTYP'], "USD" ,t,resultRatesLive)
                        SSVCFEEUSDRATE = rate_USD *float(row['SSVCFEE'])
                        SSVCFEEUSDRATE = round(SSVCFEEUSDRATE,2)
                        # print('SSVCFEEUSDRATE: ', SSVCFEEUSDRATE)
                    else:
                        # convert to USD
                        SSVCFEELOCALRATE =float( row['SSVCFEE'])
                        rate_USD = get_rate(row['SMONEYTYP'], "USD" ,t,resultRatesLive)
                        SSVCFEEUSDRATE = rate_USD *float(row['SSVCFEE'])
                        SSVCFEEUSDRATE = round(SSVCFEEUSDRATE,2)
                        # convert to EUR
                        SSVCFEELOCALRATE = float(row['SSVCFEE'])
                        rate_EUR = get_rate(row['SMONEYTYP'], "EUR" ,t,resultRatesLive)
                        SSVCFEEEURORATE = rate_EUR *float(row['SSVCFEE'])
                        SSVCFEEEURORATE = round(SSVCFEEEURORATE,2)

                print('[RECKEY]',RECKEY,'[AIRCHG]',AIRCHG,'[AIRMONEYTYPE]',AIRMONEYTYPE,'[HOTELBOOKRATE]',HOTELBOOKRATE,'[HMONEYTYPE]',HMONEYTYPE,'[CARBOOKRATE]',CARBOOKRATE,'[CARMONEYTYPE]',CARMONEYTYPE,'[SSVCFEE]',SSVCFEE,'[SMONEYTYP]',SMONEYTYP,'[AIRLOCALRATE]',AIRLOCALRATE,'[AIREURORATE]',AIREURORATE,'[AIRUSDRATE]',AIRUSDRATE,'[HOTELLOCALRATE]',HOTELLOCALRATE,'[HOTELEURORATE]',HOTELEURORATE,'[HOTELUSDRATE]',HOTELUSDRATE,'[CARLOCALRATE]',CARLOCALRATE,'[CAREURORATE]',CAREURORATE,'[CARUSDRATE]',CARUSDRATE,'[SSVCFEELOCALRATE]',SSVCFEELOCALRATE,'[SSVCFEEEURORATE]',SSVCFEEEURORATE,'[SSVCFEEUSDRATE]',SSVCFEEUSDRATE)
                # insert the results to the database
                insert = 'INSERT INTO Rate_Exchange (RECKEY , AIRCHG , AIRMONEYTYPE , HOTELBOOKRATE , HMONEYTYPE , CARBOOKRATE , CARMONEYTYPE , SSVCFEE , SMONEYTYP , AIRLOCALRATE , AIREURORATE , AIRUSDRATE , HOTELLOCALRATE , HOTELEURORATE , HOTELUSDRATE , CARLOCALRATE , CAREURORATE , CARUSDRATE , SSVCFEELOCALRATE , SSVCFEEEURORATE , SSVCFEEUSDRATE,LEGCNTR,Converted) VALUES '
                values = map((lambda x: "'"+str(x)+"'"), [RECKEY , AIRCHG , AIRMONEYTYPE , HOTELBOOKRATE , HMONEYTYPE , CARBOOKRATE , CARMONEYTYPE , SSVCFEE , SMONEYTYP , AIRLOCALRATE , AIREURORATE , AIRUSDRATE , HOTELLOCALRATE , HOTELEURORATE , HOTELUSDRATE , CARLOCALRATE , CAREURORATE , CARUSDRATE , SSVCFEELOCALRATE , SSVCFEEEURORATE , SSVCFEEUSDRATE , LEGCNTR,Converted])
                inserting = insert +'('+ ', '.join(values) +');'
                inserting= inserting.replace("'nan'",'NULL')
                inserting= inserting.replace("'NaT'",'NULL')
                inserting= inserting.replace("'None'",'NULL')
                cnxnLive.execute(inserting )
                cnxnLive.commit()
                print(i , ' --> inserted')
            except Exception as e:
                Converted ='0'
                print('error -->',e)
                # exc_type, exc_obj, exc_tb = sys.exc_info()
                # fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                # print(exc_type, fname, exc_tb.tb_lineno)
                # print (sys.exc_info())
                insert = 'INSERT INTO Rate_Exchange (RECKEY , AIRCHG , AIRMONEYTYPE , HOTELBOOKRATE , HMONEYTYPE , CARBOOKRATE , CARMONEYTYPE , SSVCFEE , SMONEYTYP , AIRLOCALRATE , AIREURORATE , AIRUSDRATE , HOTELLOCALRATE , HOTELEURORATE , HOTELUSDRATE , CARLOCALRATE , CAREURORATE , CARUSDRATE , SSVCFEELOCALRATE , SSVCFEEEURORATE , SSVCFEEUSDRATE,LEGCNTR,Converted) VALUES '
                values = map((lambda x: "'"+str(x)+"'"), [RECKEY , AIRCHG , AIRMONEYTYPE , HOTELBOOKRATE , HMONEYTYPE , CARBOOKRATE , CARMONEYTYPE , SSVCFEE , SMONEYTYP , AIRLOCALRATE , AIREURORATE , AIRUSDRATE , HOTELLOCALRATE , HOTELEURORATE , HOTELUSDRATE , CARLOCALRATE , CAREURORATE , CARUSDRATE , SSVCFEELOCALRATE , SSVCFEEEURORATE , SSVCFEEUSDRATE , LEGCNTR,Converted])
                inserting = insert +'('+ ', '.join(values) +');'
                inserting= inserting.replace("'nan'",'NULL')
                inserting= inserting.replace("'NaT'",'NULL')
                inserting= inserting.replace("'None'",'NULL')
                cnxnLive.execute(inserting )
                cnxnLive.commit()
                print(i , ' --> NOT inserted')
            print("Total Inserted Rows " + str(count))
            count = count + 1
       # InsertData = df.to_sql('Rate_Exchange_test', con = cnxnLive_Bi)
        # print(InsertData)
        # RateExchangeData = cnxnLive_Bi.execute("SELECT * FROM Rate_Exchange_test").fetchall()
        # print(RateExchangeData)
        return 'ExchangeRateSuccess'
    except Exception as e:
        return e
if __name__ == "__main__":
    exchange_rate_funct()
    # exchange_rate_funct('2021-05-31', '2021-06-06', '20210531-20210606 UpdatedMain.csv')
    # print(exchange_rate_funct)


