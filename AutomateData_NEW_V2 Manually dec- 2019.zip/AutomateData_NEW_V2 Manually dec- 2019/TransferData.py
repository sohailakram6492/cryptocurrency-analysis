import pyodbc
import pandas as pd
import csv
import numpy as np
import chardet
import sys
# reload(sys)
# sys.setdefaultencoding('utf-8')
# Shows all columns
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

# ########Connect to database start here########
cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=sql-looker-db.database.windows.net;"
                         "Database=Looker_live;" 
                         "uid=atg-admin;pwd=Travel@123;")
cursor = cnxnLive.cursor()

# read database
# DataFileName= '202011Main.xlsx'
# df = pd.read_excel(DataFileName)




def insert_records(table, mycsv,StartDate,EndDate):
    print("\n----------------Master Data Script Function--------------------\n")
    #INSERT SOURCE RECORDS TO DESTINATION
    try:
        df = pd.read_excel(mycsv)
        # df.fillna('', inplace=True)
        headers = map((lambda x: x.strip()), df.columns)

        # below code will help to not insert the same data twice
        Reckey = pd.read_sql_query("SELECT RECKEY,LEGCNTR FROM MasterTrip WHERE ACCT IN ('MERCKCN11C') AND invdate BETWEEN '"+StartDate+"' and '"+EndDate+"'", cnxnLive)
        Reckey['recleg'] = Reckey['RECKEY'].apply(str) +'_' + Reckey['LEGCNTR'].apply(str)
        
        df.columns= df.columns.str.upper()
        df['recleg'] = df['RECKEY'].apply(str) +'_' + df['LEGCNTR'].apply(str)
        df = df[~df.recleg.isin(Reckey['recleg'])]
        
        del df['recleg']
        print('Fetch Data')

        # clean data field
        df['INVDATE'] = pd.to_datetime(df['INVDATE'], errors='coerce')
        df['BOOKDATE'] = pd.to_datetime(df['BOOKDATE'], errors='coerce')
        df['DEPDATE'] = pd.to_datetime(df['DEPDATE'], errors='coerce')
        df['ARRDATE'] = pd.to_datetime(df['ARRDATE'], errors='coerce')
        df['DATEIN'] = pd.to_datetime(df['DATEIN'], errors='coerce')
        df['CHECKOUT'] = pd.to_datetime(df['CHECKOUT'], errors='coerce')
        df['RENTDATE'] = pd.to_datetime(df['RENTDATE'], errors='coerce')
        df['RETURNDATE'] = pd.to_datetime(df['RETURNDATE'], errors='coerce')
        df['RDEPDATE'] = pd.to_datetime(df['RDEPDATE'], errors='coerce')
        df['RARRDATE'] = pd.to_datetime(df['RARRDATE'], errors='coerce')
        df['STRANDATE'] = pd.to_datetime(df['STRANDATE'], errors='coerce')
        df = df.replace("'",' ',regex=True)
        header = df.columns.tolist()
        headers = map((lambda x: x.strip()), header)
        
        insert = 'INSERT INTO {} ('.format(table) + ', '.join(headers) + ') VALUES '
        df['uploaded']=['0']*df.shape[0]
        # try:
        # exit()
        rowCount = 1
        for i,row in df.iterrows():
            values = map((lambda x: "'"+str(x)+"'"), row[:-1])
            inserting = insert +'('+ ', '.join(values) +');'
            inserting= inserting.replace("'nan'",'NULL')
            inserting= inserting.replace("'NaT'",'NULL')
            print(inserting)
            cnxnLive.execute(inserting )
            
            print('Inerted Records' + str(rowCount))
            rowCount = rowCount +1
            df.loc[i, 'uploaded'] = "1"
        cnxnLive.commit()
            #print(mycsv+'uploading row number: ',i)
            # b_cnxn.commit() #must commit unless your sql database auto-commits
        # except:
        #     df.to_excel('Expect.csv')
        df.to_csv('Expect_'+mycsv,index=False)

        # inserting into LegRoutig Table specific fields (origin, destination, miles, etc...)
        insert_query = ("INSERT INTO LegRouting (reckey,rplusmin, plusmin , airline ,origin , destinat , rdepdate, rarrdate, rarrdttim,Class,farebase, fltno,seqno,segment_no,connect,actfare,segamt,miles, Mode, r_plusmin, ditcode,tktdesig,orgctrycod,dstctrycod,flduration,legplusmin,legcntr, domintl, recloc,rdepdttim) select reckey,rplusmin, plusmin , airline ,origin , destinat , rdepdate, rarrdate, rarrdttim,Class,farebase, fltno,seqno,segment_no,connect,actfare,segamt,miles, Mode, r_plusmin, ditcode,tktdesig,orgctrycod,dstctrycod,flduration,legplusmin,legcntr, domintl, recloc,rdepdttim FROM MasterTrip WHERE mode in('A', 'R') AND reckey IN (SELECT reckey FROM MasterTrip WHERE invdate Between '"+StartDate+"' AND '"+EndDate+"') AND ACCT IN ('KAERCHDE1C','KAERCHDE2C','KAERCHDE3C','KAERCHDE4C','KAERCHDE6C','KAERCHDE7C','KAERCHDE8C','KAERCHDE9C','KAERCHDE5C','KAERCHFR1C','KAERCHD10C') ")
        print(insert_query)
        cursor.execute(insert_query)
        cursor.commit()

        # df1 = pd.read_excel(mycsv)
        # mode = ['A','R']
        # df1 = df1[df1['MODE'].isin(mode)]
        # print(len(df1))
        # counting = 1
        # # df1 = df1.fillna(value=np.nan)
        # df1.fillna('', inplace=True)
        # df1.replace(['','nan', 'Null'], 'NULL', inplace=True)
        # for i,row in df1.iterrows():
        #     df1.fillna('Null', inplace=True)
        #     df1.replace(['NaT', 'nan', '', 'NaN'], 'Null', inplace=True)
        #     reckey = row['RECKEY']
        #     rplusmin = row['RPLUSMIN']
        #     plusmin = row['PLUSMIN']
        #     airline = row['AIRLINE']
        #     origin = row['ORIGIN']
        #     destinat = row['DESTINAT']
        #     rdepdate = row['RDEPDATE']
        #     rarrdate = row['RARRDATE']
        #     rarrdttim = row['RARRDTTIM']
        #     Class = row['CLASS']
        #     farebase = row['FAREBASE']
        #     fltno = row['FLTNO']
        #     seqno = row['SEQNO']
        #     segment_no = row['SEGMENT_NO']
        #     connect = row['CONNECT']
        #     actfare = row['ACTFARE']
        #     segamt = row['SEGAMT']
        #     miles = row['MILES']
        #     Mode = row['MODE']
        #     r_plusmin = row['R_PLUSMIN']
        #     ditcode = row['DITCODE']
        #     tktdesig = row['TKTDESIG']
        #     orgctrycod = row['ORGCTRYCOD']
        #     dstctrycod = row['DSTCTRYCOD']
        #     flduration = row['FLDURATION']
        #     legplusmin = row['LEGPLUSMIN']
        #     legcntr = row['LEGCNTR']
        #     domintl = row['DOMINTL']
        #     recloc = row['RECLOC']
        #     sql = "INSERT INTO LegRouting (reckey,rplusmin, plusmin , airline ,origin , destinat , rdepdate, rarrdate, rarrdttim,Class,farebase, fltno,seqno,segment_no,connect,actfare,segamt,miles, Mode, r_plusmin, ditcode,tktdesig,orgctrycod,dstctrycod,flduration,legplusmin,legcntr, domintl, recloc) VALUES (?,?,?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        #     val = (reckey,rplusmin,plusmin,airline,origin,destinat,rdepdate,rarrdate,rarrdttim,Class,farebase,fltno,seqno, segment_no,connect,actfare,segamt, miles,Mode,r_plusmin,ditcode,tktdesig,orgctrycod, dstctrycod, flduration,legplusmin,legcntr,domintl,recloc)
        #     print(sql,val)
        #     cursor.execute(sql, val)

        #     print("Inserted Records", counting)
        #     counting += 1
        # cursor.commit()

        return 'TranferDataSuccessfully'
    except:
        e = sys.exc_info()
        return e


if __name__ == "__main__":
	insert_records()
	# Response = insert_records('MasterTrip', 'Updated 202102Main.xlsx', '2021-06-07', '2021-06-13')
	# print(Response)
