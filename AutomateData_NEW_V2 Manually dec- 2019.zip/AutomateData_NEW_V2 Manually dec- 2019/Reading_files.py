
from pandas.core.indexes.base import Index
import pyodbc
import pandas as pd
import csv
import numpy as np
import chardet
import sys
import datetime
from datetime import date, timedelta
from itertools import groupby

cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=sql-looker-db.database.windows.net;"
                         "Database=Looker_live;" 
                         "uid=atg-admin;pwd=Travel@123;")
cursor = cnxnLive.cursor()


def Filesreading(MainFileName,StartDate,EndDate,ProcessPerameter):
    try:
        dfmain = pd.read_excel(MainFileName)
        dfmain.columns = [x.upper() for x in dfmain.columns]
        reclocdist = pd.read_sql_query("SELECT DISTINCT RECLOC,RECKEY FROM MasterTrip WHERE invdate between '"+StartDate+"' and '"+EndDate+"'", cnxnLive)
        # print(reclocdist['RECLOC'])

        # collect records with same recloc from database (MasterTrip) and received file
        df_same = dfmain[dfmain['RECLOC'].isin(reclocdist['RECLOC'])]
        df_same_n = dfmain[~(dfmain['RECKEY'].isin(df_same['RECKEY']))]
        dfmain = df_same_n[~(df_same_n['RECKEY'].isin(df_same['RECKEY']))]
        dfmain = dfmain[~(dfmain['RECKEY'].isin(reclocdist['RECKEY']))]
        CntryContinent = pd.DataFrame()
        CntryContinent.reset_index(inplace=True)
        CntryContinent = pd.read_sql_query("SELECT * from CountryContinent", cnxnLive)
        
        MasterAccounts = pd.read_sql_query("SELECT * FROM MasterAccount",cnxnLive)
        # print(MasterAccounts)
        Hotel_Money_Type = dfmain[(dfmain['HMONEYTYPE'].isin(['USD', 'EUR'])) & (dfmain['BOOKRATE']> 1000)]
        Air_Money_Type = dfmain[(dfmain['MONEYTYPE'].isin(['USD', 'EUR'])) & (dfmain['AIRCHG']> 10000)]
        Hotel_Money_Type = Hotel_Money_Type.append(Air_Money_Type)
        # Hotel_Money_Type.to_excel('Hotel_Air_MoneyType('+StartDate+' to '+EndDate+').xlsx',index=False)
        for i, row in dfmain.iterrows():
            if (row['HMONEYTYPE'] == 'USD' or row['HMONEYTYPE'] == 'EUR') and (row['BOOKRATE'] > 1000):
                Account_same = MasterAccounts[MasterAccounts['acc_number']== row['ACCT']]
                if len(Account_same) >0:
                    print('In hotel currency')
                    for j,row1 in MasterAccounts.iterrows():
                        dfmain.loc[i,'HMONEYTYPE'] = row1['currency']
            
            if (row['MONEYTYPE'] == 'USD' or row['HMONEYTYPE'] == 'USD') and (row['AIRCHG'] > 10000):
                Account_same = MasterAccounts[MasterAccounts['acc_number']== row['ACCT']]
                if len(Account_same) >0:
                    print('in air currency')
                    for j,row2 in MasterAccounts.iterrows():
                        dfmain.loc[i,'MONEYTYPE'] = row2['currency']
            
        # FileNameMain = 'New Trip File.slsx'
        # dfmain.to_excel(FileNameMain,index=False)
        # exit()
                
        # exit()
        # print(CntryContinent['code_3'])
        R_A = ['A','R']
        dfvalcarAR = dfmain[dfmain['VALCARMODE'].isin(R_A)]
        CntryContinent.fillna('Null', inplace=True)
        reckey_dict = []
        origincontinent = []

        # creating new dataframe name reckeynew and calculating origin,destination and domintl_new value 
        reckeynew = pd.DataFrame(columns=['RECKEY','regionContinent', 'domintl_new'])
        counting = 1
        for k,row in dfvalcarAR.iterrows():
            reckey_dict_new = []
            Reckey = row['RECKEY']
            
            continentlist = []
            domint_list = []
            if row['RECKEY'] not in reckey_dict:
                dfmainnew = dfmain[dfmain['RECKEY'] == Reckey]
                dfmainnew.fillna('NULL', inplace=True)
                
                for i,row1 in dfmainnew.iterrows():
                    reckey_new = row1['RECKEY']
                    
                    if row1['MODE'] == 'A':
                        orgctrycod = row1['ORGCTRYCOD']
                        dstctrycod = row1['DSTCTRYCOD']
                        # exit()
                        CntryContinentorg = CntryContinent[CntryContinent['code_3'] == orgctrycod]
                        CntryContinentdst = CntryContinent[CntryContinent['code_3'] == dstctrycod]
                        CntryContinentorg.reset_index(inplace=True)
                        CntryContinentdst.reset_index(inplace=True)
                        orgcontinent = CntryContinentorg['continent']
                        dstcontinent = CntryContinentdst['continent']
                        if str(orgcontinent) == str(dstcontinent):
                            regionContinent1 = 'Continent'
                            # continentlist.append(regionContinent1)
                        else:
                            regionContinent1 = 'Inter Continent'
                    elif row1['MODE'] == 'R':
                        regionContinent1 = 'Rail'
                    else:
                        regionContinent1 = ''
                    continentlist.append(regionContinent1)
                    if row1['DITCODE'] == 'I':
                        domin_new = 'I'
                    elif row1['DITCODE'] == 'D':
                        domin_new = 'D'
                    else:
                        domin_new = dfmainnew.loc[i,'DOMINTL']
                    domint_list.append(domin_new)
                # exit()
                if 'I' in domint_list:
                    domintl_new = 'I'
                elif 'D' in domint_list:
                    domintl_new = 'D'
                else:
                    domintl_new = ''
                if 'Rail' in continentlist:
                    regionContinent = 'Rail'
                elif 'Inter Continent' in continentlist:
                    regionContinent = 'Inter Continent'
                elif 'Continent' in continentlist:
                    regionContinent = 'Continent'
                else:
                    regionContinent = ''
                reckeynew = reckeynew.append({'RECKEY': Reckey, 'regionContinent': regionContinent, 'domintl_new': domintl_new},ignore_index=True)
            # print(len(reckey_dict_new))
            reckey_dict.append(Reckey)
            print('Total Updated Records -> ', counting)
            counting += 1
        print(len(reckey_dict))
        # reckeynew.to_csv('mainnew.csv')
        dfmain = dfmain.merge(reckeynew, on='RECKEY', how='outer')
        # dfmain = dfmain.merge(domint_df, on='reckey', how='inner')
        print(dfmain)
        print(str('Updated ')+MainFileName)
        FileNameMain = str('Updated ')+ MainFileName
        if ProcessPerameter == 'Monthly':
            dfmain['ProcessFile'] = 'M'
        else:
            dfmain['ProcessFile'] = 'W'

        dfmain.to_excel(FileNameMain,index=False)
        return 'Reading File Success'
    except:
        e = sys.exc_info()
        return e

if __name__ == "__main__":
	Filesreading()
	# Response = Filesreading('Master Trip file Aug 2021.xlsx','2021-08-01' ,'2021-08-31', 'Monthly')
	# print(Response)