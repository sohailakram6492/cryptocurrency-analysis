
try:
    class Paksa1:
        def assign_string_one(self,str1):
            self.str1=str1
        def show_string_one(self):
            return self.str1
    # You sent
    class Shapewear2:
        def assign_string_two(self,str2):
            self.str2=str2
        def show_string_two(self):
            return self.str2
    # You sent
    class PaksaIT(Paksa1,Shapewear2):
        def assign_string_three (self,str3):
            self.str3 = str3
        def show_string_three(self):
            return self.str3
    # You sent
    my_paksaIT = PaksaIT()
    print(my_paksaIT)
    # You sent
    my_paksaIT.assign_string_one("I am Paksa1")
    print(my_paksaIT)
    # You sent
    my_paksaIT.assign_string_two("I am Shapewear2")
    print(my_paksaIT)
except Exception as e:
    print(e)



if __name__ == "__main__":
    class_name_insert_function()