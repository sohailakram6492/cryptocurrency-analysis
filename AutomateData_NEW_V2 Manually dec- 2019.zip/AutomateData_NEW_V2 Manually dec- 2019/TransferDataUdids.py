

import pyodbc
import pandas as pd
import csv
import numpy as np
import chardet
import sys
# reload(sys)
# sys.setdefaultencoding('utf-8')
# Shows all columns
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

########Connect to database start here########
cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=sql-looker-db.database.windows.net;"
                         "Database=Looker_live;" 
                         "uid=atg-admin;pwd=Travel@123;")
cursor = cnxnLive.cursor()

# read database
# DataFileName= '202011UDID.xlsx'

def udid_insert_records(table, DataFileName,StartDate,EndDate):
    print("\n----------------UDIDS Data Insertion Script Function--------------------\n")
    cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=sql-looker-db.database.windows.net;"
                         "Database=Looker_live;" 
                         "uid=atg-admin;pwd=Travel@123;")
    #INSERT SOURCE RECORDS TO DESTINATION
    # df = pd.read_excel(DataFileName)
    # df.columns =['INVDATE' , 'UDID1' , 'UDID2' , 'UDID3' , 'UDID4' , 'UDID5' , 'UDID6' , 'UDID7' , 'UDID8' , 'UDID9' , 'UDID10' , 'UDID11' , 'UDID12' , 'UDID13' , 'UDID14' , 'UDID15' , 'UDID16' , 'UDID17' , 'UDID18' , 'UDID19' , 'UDID20' , 'UDID21' , 'UDID22' , 'UDID23' , 'UDID24' , 'UDID25' , 'UDID26' , 'UDID27' , 'UDID28' , 'UDID29' , 'UDID30' , 'UDID31' , 'UDID32' , 'UDID33' , 'UDID34' , 'UDID35' , 'UDID36' , 'UDID37' , 'UDID38' , 'UDID39' , 'UDID40' , 'UDID41' , 'UDID42' , 'UDID43' , 'UDID44' , 'UDID45' , 'UDID46' , 'UDID47' , 'UDID48' , 'UDID49' , 'UDID50' , 'UDID51' , 'UDID52' , 'UDID53' , 'UDID54' , 'UDID55' , 'UDID56' , 'UDID57' , 'UDID58' , 'UDID59' , 'UDID60' , 'UDID61' , 'UDID62' , 'UDID63' , 'UDID64' , 'UDID65' , 'UDID66' , 'UDID67' , 'UDID68' , 'UDID69' , 'UDID70' , 'UDID71' , 'UDID72' , 'UDID73' , 'UDID74' , 'UDID75' , 'UDID76' , 'UDID77' , 'UDID78' , 'UDID79' , 'UDID80' , 'UDID81' , 'UDID82' , 'UDID83' , 'UDID84' , 'UDID85' , 'UDID86' , 'UDID87' , 'UDID88' , 'UDID89' , 'UDID90' , 'UDID91' , 'UDID92' , 'UDID93' , 'UDID94' , 'UDID95' , 'UDID96' , 'UDID97' , 'UDID98' , 'UDID99' , 'RECKEY' , 'PLUSMIN' , 'LEGPLUSMIN' , 'LEGCNTR' ]
    # df = df[[ 'RECKEY', 'LEGCNTR' , 'INVDATE', 'PLUSMIN' , 'LEGPLUSMIN'  , 'UDID1' , 'UDID2' , 'UDID3' , 'UDID4' , 'UDID5' , 'UDID6' , 'UDID7' , 'UDID8' , 'UDID9' , 'UDID10' , 'UDID11' , 'UDID12' , 'UDID13' , 'UDID14' , 'UDID15' , 'UDID16' , 'UDID17' , 'UDID18' , 'UDID19' , 'UDID20' , 'UDID21' , 'UDID22' , 'UDID23' , 'UDID24' , 'UDID25' , 'UDID26' , 'UDID27' , 'UDID28' , 'UDID29' , 'UDID30' , 'UDID31' , 'UDID32' , 'UDID33' , 'UDID34' , 'UDID35' , 'UDID36' , 'UDID37' , 'UDID38' , 'UDID39' , 'UDID40' , 'UDID41' , 'UDID42' , 'UDID43' , 'UDID44' , 'UDID45' , 'UDID46' , 'UDID47' , 'UDID48' , 'UDID49' , 'UDID50' , 'UDID51' , 'UDID52' , 'UDID53' , 'UDID54' , 'UDID55' , 'UDID56' , 'UDID57' , 'UDID58' , 'UDID59' , 'UDID60' , 'UDID61' , 'UDID62' , 'UDID63' , 'UDID64' , 'UDID65' , 'UDID66' , 'UDID67' , 'UDID68' , 'UDID69' , 'UDID70' , 'UDID71' , 'UDID72' , 'UDID73' , 'UDID74' , 'UDID75' , 'UDID76' , 'UDID77' , 'UDID78' , 'UDID79' , 'UDID80' , 'UDID81' , 'UDID82' , 'UDID83' , 'UDID84' , 'UDID85' , 'UDID86' , 'UDID87' , 'UDID88' , 'UDID89' , 'UDID90' , 'UDID91' , 'UDID92' , 'UDID93' , 'UDID94' , 'UDID95' , 'UDID96' , 'UDID97' , 'UDID98' , 'UDID99'  ]]

    try:
        df = pd.read_excel(DataFileName)
        print(len(df))
        
        df.columns =['INVDATE' , 'UDID1' , 'UDID2' , 'UDID3' , 'UDID4' , 'UDID5' , 'UDID6' , 'UDID7' , 'UDID8' , 'UDID9' , 'UDID10' , 'UDID11' , 'UDID12' , 'UDID13' , 'UDID14' , 'UDID15' , 'UDID16' , 'UDID17' , 'UDID18' , 'UDID19' , 'UDID20' , 'UDID21' , 'UDID22' , 'UDID23' , 'UDID24' , 'UDID25' , 'UDID26' , 'UDID27' , 'UDID28' , 'UDID29' , 'UDID30' , 'UDID31' , 'UDID32' , 'UDID33' , 'UDID34' , 'UDID35' , 'UDID36' , 'UDID37' , 'UDID38' , 'UDID39' , 'UDID40' , 'UDID41' , 'UDID42' , 'UDID43' , 'UDID44' , 'UDID45' , 'UDID46' , 'UDID47' , 'UDID48' , 'UDID49' , 'UDID50' , 'UDID51' , 'UDID52' , 'UDID53' , 'UDID54' , 'UDID55' , 'UDID56' , 'UDID57' , 'UDID58' , 'UDID59' , 'UDID60' , 'UDID61' , 'UDID62' , 'UDID63' , 'UDID64' , 'UDID65' , 'UDID66' , 'UDID67' , 'UDID68' , 'UDID69' , 'UDID70' , 'UDID71' , 'UDID72' , 'UDID73' , 'UDID74' , 'UDID75' , 'UDID76' , 'UDID77' , 'UDID78' , 'UDID79' , 'UDID80' , 'UDID81' , 'UDID82' , 'UDID83' , 'UDID84' , 'UDID85' , 'UDID86' , 'UDID87' , 'UDID88' , 'UDID89' , 'UDID90' , 'UDID91' , 'UDID92' , 'UDID93' , 'UDID94' , 'UDID95' , 'UDID96' , 'UDID97' , 'UDID98' , 'UDID99' , 'RECKEY' , 'PLUSMIN' , 'LEGPLUSMIN' , 'LEGCNTR' ]
        df = df[[ 'RECKEY', 'LEGCNTR' , 'INVDATE', 'PLUSMIN' , 'LEGPLUSMIN'  , 'UDID1' , 'UDID2' , 'UDID3' , 'UDID4' , 'UDID5' , 'UDID6' , 'UDID7' , 'UDID8' , 'UDID9' , 'UDID10' , 'UDID11' , 'UDID12' , 'UDID13' , 'UDID14' , 'UDID15' , 'UDID16' , 'UDID17' , 'UDID18' , 'UDID19' , 'UDID20' , 'UDID21' , 'UDID22' , 'UDID23' , 'UDID24' , 'UDID25' , 'UDID26' , 'UDID27' , 'UDID28' , 'UDID29' , 'UDID30' , 'UDID31' , 'UDID32' , 'UDID33' , 'UDID34' , 'UDID35' , 'UDID36' , 'UDID37' , 'UDID38' , 'UDID39' , 'UDID40' , 'UDID41' , 'UDID42' , 'UDID43' , 'UDID44' , 'UDID45' , 'UDID46' , 'UDID47' , 'UDID48' , 'UDID49' , 'UDID50' , 'UDID51' , 'UDID52' , 'UDID53' , 'UDID54' , 'UDID55' , 'UDID56' , 'UDID57' , 'UDID58' , 'UDID59' , 'UDID60' , 'UDID61' , 'UDID62' , 'UDID63' , 'UDID64' , 'UDID65' , 'UDID66' , 'UDID67' , 'UDID68' , 'UDID69' , 'UDID70' , 'UDID71' , 'UDID72' , 'UDID73' , 'UDID74' , 'UDID75' , 'UDID76' , 'UDID77' , 'UDID78' , 'UDID79' , 'UDID80' , 'UDID81' , 'UDID82' , 'UDID83' , 'UDID84' , 'UDID85' , 'UDID86' , 'UDID87' , 'UDID88' , 'UDID89' , 'UDID90' , 'UDID91' , 'UDID92' , 'UDID93' , 'UDID94' , 'UDID95' , 'UDID96' , 'UDID97' , 'UDID98' , 'UDID99'  ]]
        
        headers = map((lambda x: x.strip()), df.columns)
        # below code will help to not insert the same data twice
        Reckey = pd.read_sql_query("SELECT RECKEY,LEGCNTR FROM UDIDS WHERE INVDATE between '"+StartDate+"' and '"+EndDate+"'", cnxnLive)
        Reckey['recleg'] = Reckey['RECKEY'].apply(str) +'_' + Reckey['LEGCNTR'].apply(str)

        df['recleg'] = df['RECKEY'].apply(str) +'_' + df['LEGCNTR'].apply(str)
        df = df[~df.recleg.isin(Reckey['recleg'])]
        del df['recleg']
        
        # clean data field and conveert invdate to date type data
        df['INVDATE'] = pd.to_datetime(df['INVDATE'], errors='coerce')
        # REPLACE ' with empty space so when insert sql we dont get errors
        df = df.replace("'",' ',regex=True)
        # below lines will helep tp write the sql insert statement instead of doing it manuly
        header = df.columns.tolist()
        headers = map((lambda x: x.strip()), header)
        insert = 'INSERT INTO {} ('.format(table) + ', '.join(headers) + ') VALUES '
        df['uploaded']=['0']*df.shape[0]
        # try:
        # now we loop throuigh df data by line and replace 'nan' with null and insert to database
        rowCount = 1
        for i,row in df.iterrows():
            values = map((lambda x: "'"+str(x)+"'"), row[:-1])
            inserting = insert +'('+ ', '.join(values) +');'
            inserting= inserting.replace("'nan'",'NULL')
            inserting= inserting.replace("'NaT'",'NULL')
            print(inserting)
            cnxnLive.execute(inserting )
            print('Inerted Records' + str(rowCount))
            df.loc[i, 'uploaded'] = "1"
            rowCount = rowCount +1
        cnxnLive.commit()

            #print(DataFileName+'uploading row number: ',i)
            # b_cnxn.commit() #must commit unless your sql database auto-commits
        # except:
        #     df.to_excel('Expect.csv')
        df.to_csv('Expect_'+DataFileName,index=False)
        return 'UdidDataInsertSuccessfully'
    except:
        e = sys.exc_info()
        return e


if __name__ == "__main__":
	udid_insert_records()
    # udid_insert_records('UDIDS', '20210531-20210606 UpdatedUDID.csv','2021-05-31', '2021-06-06')
    # print(udid_insert_records)
