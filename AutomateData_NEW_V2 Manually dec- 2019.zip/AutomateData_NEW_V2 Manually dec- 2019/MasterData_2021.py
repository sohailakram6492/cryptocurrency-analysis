import pandas as pd
import pyodbc



cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=sql-looker-db.database.windows.net;"
                         "Database=Looker_live;" 
                         "uid=atg-admin;pwd=Travel@123;")
cursor = cnxnLive.cursor()


# df = pd.read_sql_query("Select * from MASTERDATA_NEW where invdate like '2021%' ", cnxnLive)
# print(df)
df = pd.read_csv('MasterData_2021.csv')

dropduplicate = df.drop_duplicates(keep='first')

print(len(df))
print('\n after remove duplicates -->',len(dropduplicate))

reckey = df.drop_duplicates(subset=['reckey'], keep='first')
reckey_pseudocity = df.drop_duplicates(subset=['reckey','pseudocity'], keep='first')

Some_different_columns = df.drop_duplicates(subset=['invoice','bkagent', 'tkagent','agentid','pseudocity', 'ticket','break_1', 'break_2','break_3','employeeid'], keep='first')

print(len(reckey))
reckey.to_csv('Reckey_duplicates_remove.csv')
print(len(reckey_pseudocity))
reckey_pseudocity.to_csv('reckey_and_pseudocity.csv')


Some_different_columns.to_csv('Some_different_columns.csv')