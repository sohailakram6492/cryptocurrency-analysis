import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
def sendEmail(EmailSubject,EmailMsg):
    port = 587  # For SSL
    smtp_server = "smtp.office365.com"
    sender_email = "noreply@atgtravel.com"  # Enter your address
    receiver_email = "yshaukat.up@gmail.com"  # Enter receiver address
    password = "guTaYxdaNLBV*Sks86LpsRD4huy3BzA2*j&g7Hv^"
    try:
        print('------Email Sending Process------------')
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = EmailSubject
        message = EmailMsg
        msg.attach(MIMEText(message))

        mailserver = smtplib.SMTP(smtp_server,port)
        # identify ourselves to smtp gmail client
        mailserver.ehlo()
        # secure our email with tls encryption
        mailserver.starttls()
        # re-identify ourselves as an encrypted connection
        mailserver.ehlo()
        mailserver.login(sender_email, password)

        mailserver.sendmail(sender_email,receiver_email,msg.as_string())

        mailserver.quit()
        return 'EmailSend'
    except Exception as e:
        return e
if __name__ == "__main__":
    #sendEmail()
    sendEmail('Testing Automate','User for testing purpose')