import pyodbc
import pandas as pd
import dateparser as dp
import pandas as pd
import numpy as np
import time
import os
from shutil import move,rmtree
from dateutil.parser import parse
import sys
sys.path.append(os.path.abspath('C:/Extracts/IN'))
import datetime 

########Connect to database start here########
cnxnLive = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                        "Server=atg-dev.database.windows.net;"
                         "Database=atgdevdb;" 
                         "uid=atg-admin;pwd=dev13579*;")
TcacctsLive = pd.read_sql_query('''SELECT *  FROM globalAccounts_globalaccount ''', cnxnLive)

# Getting Airport data from PNR DB
# cnxnLive_PNR = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
#                         "Server=tcp:atg-prod.database.windows.net;"
#                          "Database=ATGPNRDB_LIVE;" 
#                          "uid=yasir;pwd=fVQvb9p4Fyfqxfhk8i9JPT93txyis9ZWRdgV2gbqkUHXB5inKs;")

looker_con = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                            "Server=sql-looker-db.database.windows.net;"
                            "Database=Looker_live;"
                            "uid=atg-admin;pwd=Travel@123;")

AirportData = pd.read_sql_query("SELECT * FROM [dbo].[AirportData]", looker_con)

account_list = TcacctsLive.loc[:,['AIAN_DK','acc_name','acc_number','agency','agency_email','client','company','country','created_at','created_by_id','currency','id','login_id','note','status','updated_at','updated_by_id']]
account_list.columns =["AIAN/DK" , "Account Name" , "Acct Number" , "Agency" , "AgencyEmail" , "Client" , "Company" , "Country" , "created_at" , "created_by_id" , "Currency" , "id" , "LoginID" , "Notes" , "Status" , "updated_at" , "updated_by_id"]

start_time = datetime.datetime.now()
# Getting Today's Date
dst_file = time.strftime("%m_%d_%Y")
os.mkdir(dst_file) if not os.path.exists(dst_file) else print('Folder exists already')
    
print ("ALL ATS Script Processing Begins:")
date = time.strftime("%m_%d_%Y")  

headers = pd.read_csv('headers.csv')
def column_header(df):
    col = pd.DataFrame(columns = headers[df].loc[headers[df].notnull()])
    return col
    
# Assigning TCLEGS Column of headers to legs DataFrame
legs = column_header('TCLEGS')
# pd.DataFrame(columns = headers['TCLEGS'].loc[headers['TCLEGS'].notnull()])

# Assigning TCHOTEL Column of headers to hotels DataFrame
hotels = pd.DataFrame(columns = headers['TCHOTEL'].loc[headers['TCHOTEL'].notnull()])

# Assigning TCCARS Column of headers to cars DataFrame
cars = pd.DataFrame(columns = headers['TCCARS'].loc[headers['TCCARS'].notnull()])

# Assigning TCTRIPS Column of headers to trips DataFrame
trips = pd.DataFrame(columns = headers['TCTRIPS'].loc[headers['TCTRIPS'].notnull()])

# Assigning TCSRVICES Column of headers to services DataFrame
services = pd.DataFrame(columns = headers['TCSERVICES'].loc[headers['TCSERVICES'].notnull()])

# Assigning TCACCTS Column of headers to accts DataFrame
accts = pd.DataFrame(columns = headers['TCACCTS'].loc[headers['TCACCTS'].notnull()])

# Assigning TCUDIDS Column of headers to udids DataFrame
udids = pd.DataFrame(columns = headers['TCUDIDS'].loc[headers['TCUDIDS'].notnull()])

#########################################################################################################################################
account_dict = {}
# Assigning account name to account number in newly created account_dict Dictionary.
for i, row in account_list.iterrows():
    account_dict[str(row['Acct Number']).strip().replace('.0', '')] = row['Account Name']

# Reading Files to create 7 files
raw = pd.read_excel('Trax-APR-2020.xlsx')
raw = raw.fillna('')

def PassengerNameslash(name):
	# print(name)
	if '/' in name:
		passname = name.split('/')[0].upper()
		# print(passname)
	elif ' ' in name:
		passname = name.split(' ')[0].upper()
		# print(passname)
	return passname

def PassengerNamespace(name):
	# print(name)
	if '/' in name:
		passname = (' ').join(name.split('/')[1::]).upper()
		# print(passname)
	elif ' ' in name:
		passname = (' ').join(name.split(' ')[1::]).upper()
		# print(passname)
	return passname

print('......Creating Tctrips file......')
trips['RECKEY'] = raw['Sl No']
trips['INVOICE'] = raw['Document Date'].apply(lambda X: X[5:])
trips['PASSLAST'] = raw['Pax Name'].apply(lambda x: PassengerNameslash(str(x)) if x != '' else '' )
trips['PASSFRST'] = raw['Pax Name'].apply(lambda x: PassengerNamespace(str(x)) if x != '' else '')
trips['INVDATE'] = pd.to_datetime(trips['INVDATE']).dt.strftime('%m/%d/%Y')
trips['PLUSMIN'] = raw['No Of Pax'].apply(lambda X: -1 if '-' in str(X) else '1' )
trips['RECLOC'] = raw['PNR No']
trips['TICKET'] = raw['Ticket']
trips['DEPDATE'] = pd.to_datetime(raw['Travel Date']).dt.strftime('%m/%d/%Y')
trips['TRAVELERID'] = raw['Emp. No']
trips['SVCFEE'] = raw['Service fee ']
trips['BOOKDATE'] = pd.to_datetime(trips['BOOKDATE'], format='%m/%d/%Y')

legs['RECKEY'] = trips['RECKEY'].apply(lambda x:str(int(x)) if x else '')
legs['AIRLINE'] = trips['VALCARR']
legs['MODE'] = trips['VALCARRMOD']
legs['RDEPDATE'] = trips['DEPDATE']

for m, row in raw.iterrows():
    print("in for loop")
    RoutingCity = raw.loc[m, ['Sector Name']]
    print(RoutingCity)
    RoutingCity = str(RoutingCity[0]).split('/')
    print(RoutingCity)
    legsLen = len(RoutingCity) 
    print(legsLen)
    total_length = (legsLen // 2)
    print(total_length)
    exit()
    for counter in range(total_length):
        counter_index = counter * 2
        legs.loc[j, 'RECKEY'] = row['RECKEY']
        # legs.loc[j, 'DOMINTL'] = row['DOMINTL']
        
        origincntry = AirportData[AirportData['City'] == RoutingCity[counter_index].strip()]
        destinatncntry = AirportData[AirportData['City'] == RoutingCity[counter_index + 1].strip()]
        # print(origincntry)
        # print(destinatncntry)
        for n, row1 in origincntry.iterrows():
            legs.loc[j, 'ORIGINCTRY'] = row1['country_Code_3']
            legs.loc[j, 'ORIGIN'] = row1['IATA']
            # print('origin')
            # print(legs.loc[j, 'RECKEY'], '----->', legs.loc[j, 'ORIGIN'], legs.loc[j, 'ORIGINCTRY'])
        
        for n, row1 in destinatncntry.iterrows():
            legs.loc[j, 'DESTCTRY'] = row1['country_Code_3']
            legs.loc[j, 'DESTINAT'] = row1['IATA']
            # print('destination')
            # print(legs.loc[j, 'RECKEY'], '----->', legs.loc[j, 'DESTINAT'], legs.loc[j, 'DESTCTRY'])
        
        legs.loc[j, 'AIRLINE'] = row['VALCARR']
        
        legs.loc[j, 'SEQNO'] = counter+1
        legs.loc[j, 'SEGNUM'] = counter+1
        legs.loc[j, 'RDEPDATE'] = row['DEPDATE']
        legs.loc[j, 'MODE'] = 'A'
        legs.loc[j, 'RPLUSMIN'] = row['PLUSMIN']
        legs.loc[j, 'DOMINTL'] = row['DOMINTL']
        legs.loc[j, 'CLASS'] = row['CLASS']
        origin = legs.loc[j, 'ORIGIN']
        destinat = legs.loc[j, 'DESTINAT']
        
        # Calculating Origin Country and Destination Country 
        j += 1
    legs.to_csv('testinglegs.csv', index =False)
    exit()
    

print ("air_fin_bill passed")

exit()
for m, row in trips.iterrows():
    RoutingCity = trips.loc[m, ['voyage']]
    print(RoutingCity)
    RoutingCity = str(RoutingCity[0]).split('-')
    print(RoutingCity)
    legsLen = len(RoutingCity) 
    print(legsLen)
    
    total_length = (legsLen // 2)
    print(total_length)
    # exit()
    for counter in range(total_length):
        counter_index = counter * 2
        legs.loc[j, 'RECKEY'] = row['RECKEY']
        # legs.loc[j, 'DOMINTL'] = row['DOMINTL']
        
        origincntry = AirportData[AirportData['City'] == RoutingCity[counter_index].strip()]
        destinatncntry = AirportData[AirportData['City'] == RoutingCity[counter_index + 1].strip()]
        # print(origincntry)
        # print(destinatncntry)
        for n, row1 in origincntry.iterrows():
            legs.loc[j, 'ORIGINCTRY'] = row1['country_Code_3']
            legs.loc[j, 'ORIGIN'] = row1['IATA']
            # print('origin')
            # print(legs.loc[j, 'RECKEY'], '----->', legs.loc[j, 'ORIGIN'], legs.loc[j, 'ORIGINCTRY'])
        
        for n, row1 in destinatncntry.iterrows():
            legs.loc[j, 'DESTCTRY'] = row1['country_Code_3']
            legs.loc[j, 'DESTINAT'] = row1['IATA']
            # print('destination')
            # print(legs.loc[j, 'RECKEY'], '----->', legs.loc[j, 'DESTINAT'], legs.loc[j, 'DESTCTRY'])
        
        legs.loc[j, 'AIRLINE'] = row['VALCARR']
        
        legs.loc[j, 'SEQNO'] = counter+1
        legs.loc[j, 'SEGNUM'] = counter+1
        legs.loc[j, 'RDEPDATE'] = row['DEPDATE']
        legs.loc[j, 'MODE'] = 'A'
        legs.loc[j, 'RPLUSMIN'] = row['PLUSMIN']
        legs.loc[j, 'DOMINTL'] = row['DOMINTL']
        legs.loc[j, 'CLASS'] = row['CLASS']
        origin = legs.loc[j, 'ORIGIN']
        destinat = legs.loc[j, 'DESTINAT']
        
        # Calculating Origin Country and Destination Country 
        j += 1
    legs.to_csv('testinglegs.csv', index =False)
    exit()

AirportData.sort_values(by="IATA", axis=0, ascending=False, inplace=True, na_position='last')
j = 0
if len(air_fin_bill) > 0:
    air_fin_bill['RECKEY'] = trips['RECKEY'].apply(lambda x:str(int(x)) if x else '')
    air_fin_bill['DEPDATE'] = trips['DEPDATE']
    air_fin_bill['PLUSMIN'] = trips['PLUSMIN']
    air_fin_bill['DOMINTL'] = trips['DOMINTL']
    for i, row in air_fin_bill.iterrows():
        RoutingCity = air_fin_bill.loc[i, ['air-range code']]
        # print(RoutingCity)
        RoutingCity = str(RoutingCity[0]).split('/')
        # print(RoutingCity)
        legsLen = len(RoutingCity) - 1
        # print(legsLen)
        total_length = (legsLen // 3)
        # print(total_length)
        for counter in range(total_length):
            counter_index = counter * 3
            legs.loc[j, 'RECKEY'] = row['RECKEY']
            # legs.loc[j, 'DOMINTL'] = row['DOMINTL']
            legs.loc[j, 'ORIGIN'] = RoutingCity[counter_index]
            legs.loc[j, 'DESTINAT'] = RoutingCity[counter_index + 1]
            
            Airline_Class = RoutingCity[counter_index + 2]
            Airline_Class = Airline_Class.split(' ')
            airline_value = Airline_Class[0]
            class_value = Airline_Class[1]
            
            legs.loc[j, 'AIRLINE'] = airline_value
            legs.loc[j, 'CLASS'] = class_value
            
            legs.loc[j, 'SEQNO'] = counter+1
            legs.loc[j, 'SEGNUM'] = counter+1
            legs.loc[j, 'RDEPDATE'] = row['DEPDATE']
            legs.loc[j, 'MODE'] = 'A'
            legs.loc[j, 'RPLUSMIN'] = row['PLUSMIN']
            legs.loc[j, 'DOMINTL'] = row['DOMINTL']
            origin = legs.loc[j, 'ORIGIN']
            destinat = legs.loc[j, 'DESTINAT']
            
            # Calculating Origin Country and Destination Country 
            origincntry = AirportData[AirportData['IATA'] == origin]
            destinatncntry = AirportData[AirportData['IATA'] == destinat.strip()]

            for n, row1 in origincntry.iterrows():
                if (origin == row1['IATA']):
                    legs.loc[j, 'ORIGINCTRY'] = row1['country_Code_3']
                    # print('origin')
                    # print(legs.loc[j, 'RECKEY'], '----->', legs.loc[j, 'ORIGIN'], legs.loc[j, 'ORIGINCTRY'])
            
            for n, row1 in destinatncntry.iterrows():
                if (destinat.strip() == row1['IATA']):
                    legs.loc[j, 'DESTCTRY'] = row1['country_Code_3']
                    # print('destination')
                    # print(legs.loc[j, 'RECKEY'], '----->', legs.loc[j, 'DESTINAT'], legs.loc[j, 'DESTCTRY'])
            j += 1
else:
    trips['BOOKDATE'] = pd.to_datetime(trips['BOOKDATE'], format='%m/%d/%Y')
    AirportData.drop_duplicates(subset=['City'],keep='first', inplace=True)
    trips['CLASS'] = flights['CLASS']
    legs['RECKEY'] = trips['RECKEY'].apply(lambda x:str(int(x)) if x else '')
    legs['AIRLINE'] = trips['VALCARR']
    legs['MODE'] = trips['VALCARRMOD']
    legs['RDEPDATE'] = trips['DEPDATE']
    for m, row in trips.iterrows():
        RoutingCity = trips.loc[m, ['voyage']]
        print(RoutingCity)
        RoutingCity = str(RoutingCity[0]).split('-')
        print(RoutingCity)
        legsLen = len(RoutingCity) 
        print(legsLen)
        
        total_length = (legsLen // 2)
        print(total_length)
        # exit()
        for counter in range(total_length):
            counter_index = counter * 2
            legs.loc[j, 'RECKEY'] = row['RECKEY']
            # legs.loc[j, 'DOMINTL'] = row['DOMINTL']
            
            origincntry = AirportData[AirportData['City'] == RoutingCity[counter_index].strip()]
            destinatncntry = AirportData[AirportData['City'] == RoutingCity[counter_index + 1].strip()]
            # print(origincntry)
            # print(destinatncntry)
            for n, row1 in origincntry.iterrows():
                legs.loc[j, 'ORIGINCTRY'] = row1['country_Code_3']
                legs.loc[j, 'ORIGIN'] = row1['IATA']
                # print('origin')
                # print(legs.loc[j, 'RECKEY'], '----->', legs.loc[j, 'ORIGIN'], legs.loc[j, 'ORIGINCTRY'])
            
            for n, row1 in destinatncntry.iterrows():
                legs.loc[j, 'DESTCTRY'] = row1['country_Code_3']
                legs.loc[j, 'DESTINAT'] = row1['IATA']
                # print('destination')
                # print(legs.loc[j, 'RECKEY'], '----->', legs.loc[j, 'DESTINAT'], legs.loc[j, 'DESTCTRY'])
            
            legs.loc[j, 'AIRLINE'] = row['VALCARR']
            
            legs.loc[j, 'SEQNO'] = counter+1
            legs.loc[j, 'SEGNUM'] = counter+1
            legs.loc[j, 'RDEPDATE'] = row['DEPDATE']
            legs.loc[j, 'MODE'] = 'A'
            legs.loc[j, 'RPLUSMIN'] = row['PLUSMIN']
            legs.loc[j, 'DOMINTL'] = row['DOMINTL']
            legs.loc[j, 'CLASS'] = row['CLASS']
            origin = legs.loc[j, 'ORIGIN']
            destinat = legs.loc[j, 'DESTINAT']
            
            # Calculating Origin Country and Destination Country 
            j += 1
        legs.to_csv('testinglegs.csv', index =False)
        exit()
    
del trips['voyage']

print ("air_fin_bill passed")


exit()

for i, row in raw.iterrows():
	Tax_Amount = (row['Tax Amount']).strip('(').strip(')')
	Merchant_Fee = float(row['Merchant Fee'])
	GST_Amount = float(row['S.Tax / GST Amount'])
	print(Tax_Amount)
	print(Merchant_Fee)
	print(GST_Amount)
	FareTax = float(Tax_Amount) + float(Merchant_Fee) + float(GST_Amount)
	print('FareTax ------>',FareTax)
	trips.loc[i,'FARETAX'] = float(FareTax)

# trips['FARETAX'] = raw['FARETAX']

# print ("Accounts processing")
# accounts = trips['ACCT'].drop_duplicates()
# print(account_dict)
# for k, v in accounts.iteritems():
#     accts.loc[k, 'ACCT'] = trips['ACCT']
#     accts.loc[k, 'ACCTNAME'] = account_dict[str(v).replace('.0', '')]




print('......Creating Tcservices file......')

# Creating TCSERVICE if SVCFEE is not empty in TCTRIPS file
services_trips = trips[trips.CancellationFee != 0]
services['RECKEY'] = services_trips['RECKEY']
services['TRANDATE'] = services_trips['INVDATE'].apply(
    lambda x: parseDate(str(x))if x != '' else '')
services['SFTRANTYPE'] = services_trips['TRANTYPE']
services['MONEYTYPE']= 'INR'
services['SVCCODE'] = 'TSF'
services['SVCDESC'] = 'Cancellation Fee'
services['SVCAMT'] =trips['CancellationFee']



# Creating UDIDS for udidno 17,32,35,409 from trips file
L =[]
ud28s = pd.Series(trips['Cost Centre'].values, index=trips.RECKEY).to_dict()
for key, value in ud28s.items():
    L.append([key,'28',value])

ud27s = pd.Series(trips['TRAVELERID'].values, index=trips.RECKEY).to_dict()
for key, value in ud27s.items():
    L.append([key,'27',value])

ud509s = pd.Series(trips['supplier Code'].values, index=trips.RECKEY).to_dict()
for key, value in ud509s.items():
    print(value)
    if value in ('6E', 'SG'):
        value = 1
        print('1')
        L.append([key,'509',value])

ud17s = pd.Series(trips['BREAK1'].values, index=trips.RECKEY).to_dict()
for key, value in ud17s.items():
    L.append([key,'17',value])

del trips['Cost Centre']
del trips['CancellationFee']

udids = pd.DataFrame(L, columns=udid_headers)
udids = udids.fillna('')
udids = udids.sort_values(by=['RECKEY'])

print('......Creating Tclegs file......')

legs_trips = pd.DataFrame()
legs_trips = trips[trips.ORG_DEST != '']

legs['RECKEY'] = legs_trips['RECKEY']
legs['AIRLINE'] = legs_trips['VALCARR']
legs['RDEPDATE'] = legs_trips['DEPDATE'].apply(
    lambda x: parseDate(str(x))if x != '' else '')
legs['RARRDATE'] = legs_trips['ARRDATE'].apply(
    lambda x: parseDate(str(x))if x != '' else '')
legs['MODE'] = legs_trips['VALCARRMOD']
legs['RPLUSMIN'] = legs_trips['PLUSMIN']
legs['DOMINTL'] = legs_trips['DOMINTL']
print(legs['RARRDATE'])
print(legs['RDEPDATE'])
j = 0
for i,row in legs_trips.iterrows():
	AirlineCode1 =legs_trips.loc[i ,['VALCARR']]
	RoutingCity = legs_trips.loc[i, ['ORG_DEST']]
	RoutingCity = str(RoutingCity[0]).split('/')
	# print (AirlineCode1)
	legsLen = len(RoutingCity)
	# print(RoutingCity)
	for counter, Code in enumerate(RoutingCity):
		# print(counter)
		legs.loc[j, 'RECKEY'] = row['RECKEY']
		legs.loc[j, 'AIRLINE'] = row['VALCARR']
		legs.loc[j, 'ORIGIN'] = RoutingCity[counter]
		# print(RoutingCity[counter])
		# print(RoutingCity[counter])
		print(legsLen)
		# exit()
		if legsLen>1:
		    legs.loc[j, 'DESTINAT'] = RoutingCity[counter+1]
		    legs.loc[j, 'RDEPDATE'] = row['DEPDATE']
		    legs.loc[j, 'RARRDATE'] = row['DEPDATE']
		else:
		    legs.loc[j, 'DESTINAT'] = ''
		if counter == 0:
		    legs.loc[j, 'RDEPDATE'] = row['DEPDATE']
		    legs.loc[j, 'RARRDATE'] = row['DEPDATE']
		legs.loc[j, 'DEPTIME'] =''
		if len(RoutingCity)== counter+2 or legsLen==1:
		    legs.loc[j, 'RARRDATE'] = row['ARRDATE']
		    legs.loc[j, 'RDEPDATE'] = row['ARRDATE']
		legs.loc[j, 'FAREBASE'] = ''
		legs.loc[j, 'FLTNO'] = ''
		legs.loc[j, 'SEQNO'] = counter+1
		legs.loc[j, 'SEGNUM'] = counter+1
		legs.loc[j, 'CONNECT'] = ''
		legs.loc[j, 'ACTFARE'] = ''
		legs.loc[j, 'MISCAMT'] = ''
		legs.loc[j, 'MILES'] = ''
		legs.loc[j, 'RPLUSMIN'] = row['PLUSMIN']
		legs.loc[j, 'DOMINTL'] = row['DOMINTL']
		legs.loc[j, 'TKTDESIG'] = ''
		# legs.loc[j, 'ORIGINCTRY'] = ''
		# legs.loc[j, 'DESTCTRY'] = ''
		legs.loc[j, 'FLTDURATN'] =''
		origin = legs.loc[j, 'ORIGIN']
		destinat = legs.loc[j, 'DESTINAT']
		
		# Calculating Origin country and destination country for tclegs 
		print(origin)
		print(destinat)
		origincntry = IBank_details[IBank_details['CITY']== origin ]
		destcntry = IBank_details[IBank_details['CITY']== destinat.strip() ]
		for n, row1 in origincntry.iterrows():
			if (origin == row1['CITY']):
				legs.loc[j,'ORIGINCTRY'] = row1['COUNTRY']
				print('origin')
				print(legs.loc[j, 'RECKEY'],'----->',legs.loc[j, 'ORIGIN'], legs.loc[j,'ORIGINCTRY'])
				# print(row['RECKEY'],'----->',row[ 'ORIGIN'])

		for k, row2 in destcntry.iterrows():
			print('in destination')
			if (destinat.strip() == row2['CITY']):
				legs.loc[j,'DESTCTRY'] = row2['COUNTRY']
				print('destination')
				print(legs.loc[j, 'RECKEY'],'----->',legs.loc[j, 'DESTINAT'], legs.loc[j,'DESTCTRY'])
		j +=1
		if len(RoutingCity) ==  counter+2 or legsLen==1:
		    break


print ("FINALLY Accounts processing")
accounts = trips['ACCT'].drop_duplicates()
for k, v in accounts.iteritems():
    accts.loc[k, 'ACCT'] = v
    accts.loc[k, 'ACCTNAME'] = account_dict[str(v).replace('.0', '')]


print('\n......All files created......\n')


# Converting files to .csv format
accts.to_csv('{}\\tcaccts.csv'.format(dst_file),
             encoding='latin-1', index=False)
services.to_csv('{}\\tcservices.csv'.format(
    dst_file), encoding='latin-1', index=False)
cars.to_csv('{}\\tccars.csv'.format(dst_file), encoding='latin-1', index=False)
hotels.to_csv('{}\\tchotels.csv'.format(dst_file), encoding='latin-1', index=False)
legs.to_csv('{}\\tclegs.csv'.format(dst_file), encoding='latin-1', index=False)
udids.to_csv('{}\\tcudids.csv'.format(dst_file), index=False)
trips.to_csv('{}\\tctrips.csv'.format(dst_file), index=False)
# Moving Files to OUT Directory
# print os.path.dirname(os.getcwd())+'\\OUT' // C:\Extracts\RawDataConversion\Brazil Raw Data\OUT


dst_file_out = os.path.join('..\\OUT', date)
if os.path.exists(dst_file_out):
    rmtree(dst_file_out)

move(dst_file, os.path.dirname(os.getcwd())+'\\OUT')

# Calculate time Duration
end_time = datetime.datetime.now()
duration = 'Duration: {}'.format(end_time - start_time)
print(duration)
print(":) Good Luck and wish you for the best, Now Go to the MasterScript Bye Bye :)")
