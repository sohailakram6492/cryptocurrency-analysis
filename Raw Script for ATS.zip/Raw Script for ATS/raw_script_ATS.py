# importing libraries 
import pandas as pd
import numpy as np
import pyodbc 

dataframe = pd.read_excel('Trax-APR-2020.xlsx')
print(dataframe.info())

