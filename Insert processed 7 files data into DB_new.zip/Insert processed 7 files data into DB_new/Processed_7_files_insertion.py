import pyodbc
import pandas as pd
import numpy as np
from datetime import *
import os
from dateutil import parser
from shutil import rmtree
import urllib
from sqlalchemy import create_engine

# -----------**********---------- Creating Database connection -----------**********---------- #
DB_connection = pyodbc.connect("Driver={SQL Server};"
                      "Server=tcp:atg-prod.database.windows.net;"
                      "Database=ATGPNRDB_TEST;"
                      "uid=atg-admin;pwd=prod24680*;")
cursor = DB_connection.cursor()
# server = 'atg-prod.database.windows.net' # to specify an alternate port
# database = 'ATGPNRDB_TEST' 
# username = 'atg-admin' 
# password = 'prod24680*'
# params = urllib.parse.quote_plus("'DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password")
# engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)

def InputDate():
    first_date = parser.parse(input("Enter First date (YYYY-MM-DD format): "))
    last_date = parser.parse(input("Enter Last date (YYYY-MM-DD format): "))
    first_date = first_date.strftime("%Y-%m-%d")
    last_date = last_date.strftime("%Y-%m-%d")
    return first_date, last_date

current_directory = os.getcwd()
folder_path = [d for d in os.listdir(current_directory) if os.path.isdir(d) & (~d.startswith('.'))]

if len(folder_path) == 1:
    folder_path = folder_path[0]
else:
    print('There are two or more folder to read. Please Place 1 folder in this directory.')
    exit()

file_names = ['TCCARS.csv','TCTRIPS.csv','TCHOTEL.csv', 'TCLEGS.csv', 'TCSERVICES.csv','TCUDIDS.csv','TCACCTS.csv']
path = os.listdir(folder_path)

for i in path:
    full_path = str(current_directory)+ "\\" + str(folder_path) + "\\" + str(i)
    file_name = i.split('.')[0]
    # print(file_name)
    if file_name == 'TCTRIPS' or file_name == 'Tctrips':
        df_trips = pd.read_csv('{}'.format(full_path))
        df_trips=df_trips.fillna(np.nan).replace([np.nan], ['NULL'])
        # print(len(df_trips))
    elif file_name == 'TCHOTEL' or file_name == 'Tchotel':
        df_hotel = pd.read_csv('{}'.format(full_path))
        df_hotel=df_hotel.fillna(np.nan).replace([np.nan], ['NULL'])
        # print(len(df_hotel))
    elif file_name == 'TCLEGS' or file_name == 'Tclegs':
        df_legs = pd.read_csv('{}'.format(full_path))
        df_legs=df_legs.fillna(np.nan).replace([np.nan], ['NULL'])
        # print(len(df_legs))
    elif file_name == 'TCSERVICES' or file_name == 'Tcservices':
        df_services = pd.read_csv('{}'.format(full_path))
        df_services=df_services.fillna(np.nan).replace([np.nan], ['NULL'])
        # print(len(df_services))
    elif file_name == 'TCACCTS' or file_name == 'Tcaccts':
        df_accts = pd.read_csv('{}'.format(full_path))
        df_accts=df_accts.fillna(np.nan).replace([np.nan], ['NULL'])
        # print(len(df_accts))
    elif file_name == 'TCUDIDS' or file_name == 'Tcudids':
        df_udids = pd.read_csv('{}'.format(full_path))
        df_udids=df_udids.fillna(np.nan).replace([np.nan], ['NULL'])
        # print(len(df_udids))
    elif file_name == 'TCCARS' or file_name == 'Tccars':
        df_cars = pd.read_csv('{}'.format(full_path))
        df_cars=df_cars.fillna(np.nan).replace([np.nan], ['NULL'])
        # print(len(df_cars))

trips_acct= df_trips['ACCT'].astype(str)

def Delete_From_DB(Yes_Or_No,first_date,last_date):
    tclegs_delete_query = ("DELETE from TCLEGS_BO where RECKEY in (SELECT RECKEY FROM TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {})".format(first_date,last_date,trips_acct))
    print(tclegs_delete_query)
    # cursor.execute(tclegs_delete_query)
    # cursor.commit()
    tchotel_delete_query = ("DELETE from TCHOTEL_BO where RECKEY in (SELECT RECKEY FROM TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {})".format(first_date,last_date,trips_acct))
    print(tchotel_delete_query)
    # cursor.execute(tchotel_delete_query)
    # cursor.commit()
    tcudids_delete_query = ("DELETE from TCUDIDS_BO where RECKEY in (SELECT RECKEY FROM TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {})".format(first_date,last_date,trips_acct))
    print(tcudids_delete_query)
    # cursor.execute(tcudids_delete_query)
    # cursor.commit()
    tcservices_delete_query = ("DELETE from TCSERVIC_BO where RECKEY in (SELECT RECKEY FROM TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {})".format(first_date,last_date,trips_acct))
    print(tcservices_delete_query)
    # cursor.execute(tcservices_delete_query)
    # cursor.commit()
    tccars_delete_query = ("DELETE from TCCARS_BO where RECKEY in (SELECT RECKEY FROM TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {})".format(first_date,last_date,trips_acct))
    print(tccars_delete_query)
    # cursor.execute(tccars_delete_query)
    # cursor.commit()
    tctrips_delete_query = ("DELETE from TCTRIPS_BO WHERE INVDATE BETWEEN '{}' and '{}' AND ACCT IN {} ".format(first_date,last_date,trips_acct))
    print(tctrips_delete_query)
    # cursor.execute(tctrips_delete_query)
    # cursor.commit()

def get_non_negative_int(prompt):
    date1,date2 = InputDate()
    while True:
        try:
            print("\nAre you sure you want to delete data from Dattabse? Accounts {} and Start_Date {} and End_Date {}".format(trips_acct,date1, date2))
            value = int(input(prompt))
        except ValueError:
            print("Sorry, I didn't understand that.")
            continue
        
        if value == 1:
            # print("Sorry, your response must not be negative.")
            Delete_From_DB(value,date1,date2)
        if value < 0:
            print("Sorry, your response must not be negative.")
            continue
        elif value > 1:
            print("Sorry, your response not matched, \nPlease IF Yes Press 1 IF No press 0: ")
            continue
        else:
            break
    return value

# Inserting each DataFrame into DataBase 
def Insertion_into_DB(df_trips,df_hotel,df_cars,df_services,df_udids,df_accts,df_legs):

    cursor.execute("Select max(Reckey) from TCTRIPS_BO")
    TCtripsMax_reckey = cursor.fetchall()
    Max_Reckey = TCtripsMax_reckey[0][0]
    
    Max_Reckey = int(Max_Reckey) if Max_Reckey else int(2000000)
    print("Maximum Reckey is --------",Max_Reckey)
    
# Creating the value of RECKEY_NEW, which proceeds from the last Reckey value inserted into DB.
    Max_Reckey = Max_Reckey+1
    df_trips['RECKEY_NEW'] = np.arange((Max_Reckey),(Max_Reckey+(len(df_trips))))
    # print(df_trips['RECKEY_NEW'])

# Compare RECKEY of two DataFrame and replace the value of RECKEY with the RECKEY_NEW if both are same and drop RECKEY_NEW column
    def Replace_Reckey(df_RECKEY, df_NEW_RECKEY):
        new_df = df_RECKEY.merge(df_NEW_RECKEY[['RECKEY_NEW','RECKEY']], left_on='RECKEY', right_on='RECKEY')
        new_df['RECKEY'] = new_df['RECKEY_NEW'].astype(int)
        new_df.drop('RECKEY_NEW' , axis = 1 , inplace = True)
        return new_df

    df_hotel = Replace_Reckey(df_hotel, df_trips)
    print("---------hotels reckey created--------")
    df_cars = Replace_Reckey(df_cars, df_trips) 
    print("---------cars reckey created--------")
    df_services = Replace_Reckey(df_services, df_trips)
    print("---------service reckey created--------")
    df_legs = Replace_Reckey(df_legs, df_trips)
    print("---------legs reckey created--------")
    df_udids = Replace_Reckey(df_udids, df_trips)
    print("---------udids reckey created--------")
   
    df_trips['RECKEY'] = df_trips['RECKEY_NEW'].astype(int)
    del df_trips['RECKEY_NEW']
    print("---------trips reckey created--------")

# Creating Excel_files from DataFrames.
    df_trips.to_csv('newtrips_updated_Reckey.csv', index=False)
    df_services.to_csv('newservice_updated_Reckey.csv', index=False)
    df_legs.to_csv('newlegs_updated_Reckey.csv', index=False)
    df_udids.to_csv('newudids_updated_Reckey.csv', index=False)
    df_hotel.to_csv('newhotel_updated_Reckey.csv', index=False)
    df_cars.to_csv('newcars_updated_Reckey.csv', index=False)
  
# -----------**********---------- Insertion of data into DB starts from here -----------**********---------- #
    insert = 'INSERT INTO {} ('.format('TCTRIPS_BO') + ', '.join(df_trips.columns) + ') VALUES '
    df_trips['uploaded']=['0']*df_trips.shape[0]
    rowCount = 1
    df_trips=df_trips.replace("'",'',regex=True)
    for i,row in df_trips.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        print(inserting)
        cursor.execute(inserting )
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
    # cursor.commit()

    insert = 'INSERT INTO {} ('.format('TCHOTEL_BO') + ', '.join(df_hotel.columns) + ') VALUES '
    df_hotel['uploaded']=['0']*df_hotel.shape[0]
    rowCount = 1
    for i,row in df_hotel.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        print(inserting)
        cursor.execute(inserting )
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
    # cursor.commit()
    
    insert = 'INSERT INTO {} ('.format('TCLEGS_BO') + ', '.join(df_legs.columns) + ') VALUES '
    df_legs['uploaded']=['0']*df_legs.shape[0]
    rowCount = 1
    for i,row in df_legs.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +"("+ ", ".join(values) +");"
        print(inserting)
        cursor.execute(inserting )
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
    # cursor.commit()
    
    df_services.fillna('', inplace=True)
    insert = 'INSERT INTO {} ('.format('TCSERVIC_BO') + ', '.join(df_services.columns) + ') VALUES '
    df_services['uploaded']=['0']*df_services.shape[0]
    rowCount = 1
    for i,row in df_services.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        print(inserting)
        cursor.execute(inserting )
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
    # cursor.commit()
    
    insert = 'INSERT INTO {} ('.format('TCCARS_BO') + ', '.join(df_cars.columns) + ') VALUES '
    df_cars['uploaded']=['0']*df_cars.shape[0]
    rowCount = 1
    for i,row in df_cars.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        print(inserting)
        cursor.execute(inserting )
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
    # cursor.commit()
    
    df_accts.drop_duplicates(subset=['ACCT'], inplace=True)
    
    insert = 'INSERT INTO {} ('.format('TCACCTS_BO') + ', '.join(df_accts.columns) + ') VALUES '
    df_accts['uploaded']=['0']*df_accts.shape[0]
    rowCount = 1
    for i,row in df_accts.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        print(inserting)
        cursor.execute(inserting )
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
    # cursor.commit()
    
    insert = 'INSERT INTO {} ('.format('TCUDIDS_BO') + ', '.join(df_udids.columns) + ') VALUES '
    df_udids['uploaded']=['0']*df_udids.shape[0]
    rowCount = 1
    for i,row in df_udids.iterrows():
        values = map((lambda x: "'"+str(x)+"'"), row[:-1])
        inserting = insert +'('+ ', '.join(values) +');'
        print(inserting)
        cursor.execute(inserting )
        print('Inerted Records --->' + str(rowCount))
        rowCount = rowCount +1
    # cursor.commit()


    for i in path:
    full_path = str(current_directory)+ "\\" + str(folder_path) + "\\" + str(i)
    file_name = i.split('.')[0]
    # print(file_name)
    if file_name == 'TCTRIPS' or file_name == 'Tctrips':
        df_trips = pd.read_csv('{}'.format(full_path))
        df_trips=df_trips.fillna(np.nan).replace([np.nan], ['NULL'])
        # print(len(df_trips))
    elif file_name == 'TCHOTEL' or file_name == 'Tchotel':
        df_hotel = pd.read_csv('{}'.format(full_path))
        df_hotel=df_hotel.fillna(np.nan).replace([np.nan], ['NULL'])
        # print(len(df_hotel))
try:
    for i in path:
        full_path = str(current_directory)+ "\\" + str(folder_path) + "\\" + str(i)
        file_name = i.split('.')[0]
        if file_name == 'TCTRIPS':
            df_trips = pd.read_csv('{}'.format(full_path))
            df_trips.fillna('', inplace=True)
            # print(len(df_trips))
        elif file_name == 'TCHOTEL':
            df_hotel = pd.read_csv('{}'.format(full_path))
            df_hotel.fillna('', inplace=True)
            # print(len(df_hotel))
        elif file_name == 'TCLEGS':
            df_legs = pd.read_csv('{}'.format(full_path))
            df_legs.fillna('', inplace=True)
            # print(len(df_legs))
        elif file_name == 'TCSERVICES':
            df_services = pd.read_csv('{}'.format(full_path))
            df_services.fillna('', inplace=True)
            # print(len(df_services))
        elif file_name == 'TCACCTS':
            df_accts = pd.read_csv('{}'.format(full_path))
            df_accts.fillna('', inplace=True)
            # print(len(df_accts))
        elif file_name == 'TCUDIDS':
            df_udids = pd.read_csv('{}'.format(full_path))
            df_udids.fillna('', inplace=True)
            # print(len(df_udids))
        elif file_name == 'TCCARS':
            df_cars = pd.read_csv('{}'.format(full_path))
            df_cars.fillna('', inplace=True)
            # print(len(df_cars))
            
    Insertion_into_DB(df_trips,df_hotel,df_cars,df_services,df_udids,df_accts,df_legs)
    rmtree(folder_path)
    print('All Done, Go and Kill the ways....')
except Exception as e:
    print(e)

