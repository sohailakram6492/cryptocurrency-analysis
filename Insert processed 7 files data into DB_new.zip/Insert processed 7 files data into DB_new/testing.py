import pyodbc
import pandas as pd
import numpy as np
from datetime import *
import glob
import os
import datetime
import csv
from dateutil import parser
from shutil import rmtree

DB_connection = pyodbc.connect("Driver={SQL Server};"
                      "Server=tcp:atg-prod.database.windows.net;"
                      "Database=ATGPNRDB_TEST;"
                      "uid=atg-admin;pwd=prod24680*;")
cursor = DB_connection.cursor()

df_udids = pd.read_csv('Merck Poland Jan 2022\TCUDIDS.csv')

# df_udids.drop_duplicates(subset=['ACCT'], inplace=True)
insert = 'INSERT INTO {} ('.format('TCUDIDS_BO') + ', '.join(df_udids.columns) + ') VALUES '
df_udids['uploaded']=['0']*df_udids.shape[0]
# try:
rowCount = 1
for i,row in df_udids.iterrows():
    values = map((lambda x: "'"+str(x)+"'"), row[:-1])
    inserting = insert +'('+ ', '.join(values) +');'
    inserting = inserting.replace("'nan'",'NULL')
    inserting = inserting.replace("'NaT'",'NULL')
    print(inserting)
    cursor.execute(inserting )
    print('Inerted Records --->' + str(rowCount))
    rowCount = rowCount +1
    # df.loc[i, 'uploaded'] = "1"
# cursor.commit()